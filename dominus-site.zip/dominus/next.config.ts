import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  // Static export: deploys to Vercel, Netlify or any static host.
  output: "export",
  trailingSlash: true,
  images: { unoptimized: true },
  turbopack: {
    rules: {
      "*.css": {
        loaders: ["@tailwindcss/turbopack"],
        as: "*.css",
      },
    },
  },
};

export default nextConfig;
