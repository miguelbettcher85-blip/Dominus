# DOMINUS® — website

Next.js 16 · React 19 · TypeScript · Tailwind CSS 4 · Framer Motion · Lucide · Lenis · d3-geo

Type: Archivo (variable — expanded width for display, normal for text) + JetBrains Mono for technical labels.

White-first, black-second visual system. Static export (`out/`), ready for Vercel or any static host.

## Run

```bash
npm install
npm run dev      # http://localhost:3000
npm run build    # static site in ./out
```

On Vercel: import the repo, framework "Next.js", no extra settings.

## Structure

```
src/app/page.tsx                 home — the 8 sections
src/app/atletas/[slug]/page.tsx  athlete profile route (one static page per athlete)
src/components/sections/         Hero, Athletes, CreativeLab, Development, PerformanceRoom,
                                 Global, Expertise, Archive, Contact
src/components/athletes|projects reusable cards, profile, project tile + fullscreen modal
src/components/visuals/          logo-free visuals: wireframe ball, radar, generated artwork,
                                 athlete image placeholder
src/components/brand/Logo.tsx    DOMINUS® logo (vector, follows text colour)
src/data/demo/                   DEMONSTRATION data (fictional athletes, clubs, projects, map)
src/data/production/             real data goes here
src/lib/site.ts                  e-mail, social links, navigation
```

## Replacing demo content

1. Fill `src/data/production/index.ts` (same types as `src/data/demo/*`).
2. Photos: put files in `public/athletes/…` and `public/projects/…` and set
   `portrait`, `gallery[].src`, `cover` and `video`. Without them the site shows
   typographic placeholders — nothing breaks.
3. Hero photo: set `HERO_IMAGE` in `src/components/sections/Hero.tsx`.
4. Set `NEXT_PUBLIC_USE_DEMO_DATA=false`.
5. Official e-mail and social links: `src/lib/site.ts` (shown as "a definir" while empty).

## Contact form

The form validates every field. It only reports success after a real backend
answers `2xx`. Set `NEXT_PUBLIC_FORM_ENDPOINT` (e.g. a Formspree form URL) —
it receives `{ name, email, country, category, message, source }` as JSON.
Without an endpoint the form says that online sending is not configured and
offers e-mail instead; it never pretends to send.

## Accessibility & motion

Skip link, keyboard-operable filters, dialogs (Esc / arrows), visible focus,
`aria-live` results. `prefers-reduced-motion` disables smooth scroll, the intro
loader, the custom cursor and decorative animation.
