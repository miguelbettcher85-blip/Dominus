import { Archive } from "@/components/sections/Archive";
import { Athletes } from "@/components/sections/Athletes";
import { Contact } from "@/components/sections/Contact";
import { CreativeLab } from "@/components/sections/CreativeLab";
import { Development } from "@/components/sections/Development";
import { Expertise } from "@/components/sections/Expertise";
import { Global } from "@/components/sections/Global";
import { Hero } from "@/components/sections/Hero";
import { PerformanceRoom } from "@/components/sections/PerformanceRoom";
import { athleteOfTheMonth, athletes, getAthlete, IS_DEMO, markets, milestones, projects, reach } from "@/data";
import { buildWorldMap } from "@/lib/worldDots";

export default function Home() {
  const featuredAthlete = athleteOfTheMonth ? getAthlete(athleteOfTheMonth.slug) : undefined;
  const map = buildWorldMap(markets, 6);
  return (
    <>
      <Hero />
      <Athletes athletes={athletes} featured={featuredAthlete && athleteOfTheMonth ? { athlete: featuredAthlete, month: athleteOfTheMonth.month } : undefined} />
      <CreativeLab projects={projects} athletes={athletes} />
      <Development />
      <PerformanceRoom athletes={athletes} />
      <Global map={map} milestones={milestones} reach={reach} demo={IS_DEMO} />
      <Expertise />
      <Archive projects={projects} athletes={athletes} />
      <Contact />
    </>
  );
}
