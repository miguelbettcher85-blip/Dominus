import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { AthleteProfile } from "@/components/athletes/AthleteProfile";
import { athletes, getAthlete, projectsFor } from "@/data";

export const dynamicParams = false;

export function generateStaticParams() {
  // Static export needs at least one path; production starts empty until real athletes are added.
  return athletes.length ? athletes.map((a) => ({ slug: a.slug })) : [{ slug: "em-breve" }];
}

export async function generateMetadata({ params }: { params: Promise<{ slug: string }> }): Promise<Metadata> {
  const { slug } = await params;
  const a = getAthlete(slug);
  if (!a) return { title: "Atleta" };
  return {
    title: `${a.name} — ${a.position}`,
    description: `${a.name}, ${a.position} do ${a.club} (${a.nationality}). ${a.bio}`,
    openGraph: { title: `${a.name} — DOMINUS®`, description: a.bio, images: a.portrait ? [a.portrait] : undefined },
  };
}

export default async function Page({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const athlete = getAthlete(slug);
  if (!athlete) notFound();
  const i = athletes.indexOf(athlete);
  const next = athletes[(i + 1) % athletes.length];
  const squad = [athlete, ...athletes.filter((a) => a.slug !== slug)];
  return <AthleteProfile athlete={athlete} next={next} squad={squad} projects={projectsFor(slug)} />;
}
