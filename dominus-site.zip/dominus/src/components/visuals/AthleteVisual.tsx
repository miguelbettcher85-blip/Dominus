import type { Athlete } from "@/data/types";
import { cn, initials } from "@/lib/utils";

/**
 * Athlete image slot. Renders the real portrait when `athlete.portrait` is set;
 * otherwise a typographic placeholder that keeps the layout art-directed.
 */
export function AthleteVisual({
  athlete,
  className,
  tone = "light",
  showLabel = true,
}: {
  athlete: Pick<Athlete, "name" | "number" | "portrait" | "position" | "countryCode">;
  className?: string;
  tone?: "light" | "dark";
  showLabel?: boolean;
}) {
  if (athlete.portrait) {
    return (
      // eslint-disable-next-line @next/next/no-img-element
      <img
        src={athlete.portrait}
        alt={athlete.name}
        loading="lazy"
        className={cn("h-full w-full object-cover grayscale contrast-[1.08]", className)}
      />
    );
  }
  const dark = tone === "dark";
  const fg = dark ? "#ffffff" : "#0a0a0a";
  const n = String(athlete.number).padStart(2, "0");
  return (
    <div
      role="img"
      aria-label={`${athlete.name} — foto a adicionar`}
      className={cn("relative h-full w-full overflow-hidden", dark ? "bg-ink" : "bg-bone", className)}
    >
      <div className={cn("absolute inset-0", dark ? "bg-grid-dark" : "bg-grid")} style={{ backgroundSize: "32px 32px" }} />
      {/* soft spotlight, echoing studio lighting */}
      <div
        className="absolute inset-0"
        style={{
          background: dark
            ? "radial-gradient(60% 50% at 50% 38%, rgba(255,255,255,0.14), transparent 70%)"
            : "radial-gradient(60% 50% at 50% 38%, rgba(255,255,255,0.95), transparent 70%)",
        }}
      />
      <svg viewBox="0 0 300 400" preserveAspectRatio="xMidYMid slice" className="absolute inset-0 h-full w-full">
        <text
          x="150" y="262" textAnchor="middle" fontFamily="Archivo Variable" fontWeight={700} fontSize="230" letterSpacing="-12"
          fill={dark ? "#0a0a0a" : "#f4f4f2"} stroke={dark ? "#4a4a4a" : "#c6c6c3"} strokeWidth="2" paintOrder="stroke"
        >
          {n}
        </text>
        <text x="150" y="250" textAnchor="middle" fontFamily="Archivo Variable" fontWeight={600} fontSize="54" letterSpacing="-2" fill={fg}>
          {initials(athlete.name)}
        </text>
        {/* crosshair */}
        <g stroke={fg} strokeOpacity="0.5" strokeWidth="0.8">
          <line x1="150" y1="40" x2="150" y2="60" />
          <line x1="140" y1="50" x2="160" y2="50" />
        </g>
        <circle cx="150" cy="200" r="118" fill="none" stroke={fg} strokeOpacity="0.12" strokeDasharray="2 6" />
      </svg>
      {showLabel && (
        <span className={cn("label-sm absolute bottom-3 left-3", dark ? "text-white/50" : "text-ash")}>
          Foto · {athlete.position} · {athlete.countryCode}
        </span>
      )}
    </div>
  );
}
