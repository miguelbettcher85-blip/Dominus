"use client";
import { motion } from "framer-motion";

/** Hexagonal attribute radar (0–100) for the Performance Room. */
export function Radar({
  data,
  size = 320,
  dark = false,
  compare,
}: {
  data: { label: string; value: number }[];
  size?: number;
  dark?: boolean;
  compare?: { label: string; value: number }[];
}) {
  const c = size / 2;
  const R = size * 0.36;
  const n = data.length;
  const fg = dark ? "255,255,255" : "10,10,10";
  const pt = (i: number, v: number) => {
    const a = -Math.PI / 2 + (i / n) * Math.PI * 2;
    return [c + Math.cos(a) * R * (v / 100), c + Math.sin(a) * R * (v / 100)] as const;
  };
  const poly = (vals: number[]) => vals.map((v, i) => pt(i, v).join(",")).join(" ");

  return (
    <svg viewBox={`0 0 ${size} ${size}`} className="h-auto w-full" role="img" aria-label={data.map((d) => `${d.label} ${d.value}`).join(", ")}>
      {[20, 40, 60, 80, 100].map((r) => (
        <polygon key={r} points={poly(data.map(() => r))} fill="none" stroke={`rgba(${fg},${r === 100 ? 0.35 : 0.12})`} strokeDasharray={r === 100 ? undefined : "2 4"} />
      ))}
      {data.map((_, i) => {
        const [x, y] = pt(i, 100);
        return <line key={i} x1={c} y1={c} x2={x} y2={y} stroke={`rgba(${fg},0.12)`} />;
      })}
      {compare && (
        <polygon points={poly(compare.map((d) => d.value))} fill="none" stroke={`rgba(${fg},0.45)`} strokeDasharray="4 4" />
      )}
      <motion.polygon
        key={data.map((d) => d.value).join("-")}
        points={poly(data.map((d) => d.value))}
        fill={`rgba(${fg},0.08)`}
        stroke={`rgb(${fg})`}
        strokeWidth="1.5"
        initial={{ opacity: 0, scale: 0.6 }}
        animate={{ opacity: 1, scale: 1 }}
        style={{ transformOrigin: `${c}px ${c}px` }}
        transition={{ duration: 0.9, ease: [0.16, 1, 0.3, 1] }}
      />
      {data.map((d, i) => {
        const [x, y] = pt(i, d.value);
        const [lx, ly] = pt(i, 128);
        return (
          <g key={d.label}>
            <circle cx={x} cy={y} r="3" fill={`rgb(${fg})`} />
            <text x={lx} y={ly - 4} textAnchor="middle" fontFamily="JetBrains Mono" fontSize="9" letterSpacing="1.4" fill={`rgba(${fg},0.6)`}>
              {d.label.toUpperCase()}
            </text>
            <text x={lx} y={ly + 9} textAnchor="middle" fontFamily="Archivo Variable" fontWeight={600} fontSize="12" fill={`rgb(${fg})`}>
              {d.value}
            </text>
          </g>
        );
      })}
    </svg>
  );
}
