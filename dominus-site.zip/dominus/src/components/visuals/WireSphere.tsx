"use client";
import { useEffect, useRef } from "react";

/**
 * Rotating wireframe "ball" drawn on canvas — the hero's interactive object.
 * Lat/long mesh with a subtle organic displacement, tilted by the pointer.
 * Pauses off-screen; renders one still frame under reduced motion.
 */
export function WireSphere({ className, color = "10,10,10" }: { className?: string; color?: string }) {
  const ref = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = ref.current!;
    const ctx = canvas.getContext("2d")!;
    const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    let w = 0, h = 0, dpr = 1, raf = 0, visible = true;
    let rotY = 0.6, tiltX = -0.35, targetTiltX = -0.35, targetBoost = 0, boost = 0;

    const resize = () => {
      dpr = Math.min(2, window.devicePixelRatio || 1);
      const r = canvas.getBoundingClientRect();
      w = r.width; h = r.height;
      canvas.width = w * dpr; canvas.height = h * dpr;
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    };
    resize();
    const ro = new ResizeObserver(resize); ro.observe(canvas);
    const io = new IntersectionObserver(([e]) => { visible = e.isIntersecting; }); io.observe(canvas);

    const onMove = (e: PointerEvent) => {
      const r = canvas.getBoundingClientRect();
      const nx = (e.clientX - r.left) / r.width - 0.5;
      const ny = (e.clientY - r.top) / r.height - 0.5;
      targetTiltX = -0.35 + ny * 0.6;
      targetBoost = nx * 0.02;
    };
    window.addEventListener("pointermove", onMove);

    const LAT = 18, LON = 28;
    const disp = (la: number, lo: number, t: number) =>
      1 + 0.045 * Math.sin(la * 3 + t * 0.6) * Math.cos(lo * 2 - t * 0.4) + 0.025 * Math.sin(lo * 5 + la * 2 + t * 0.8);

    const project = (la: number, lo: number, t: number, R: number, cx: number, cy: number) => {
      const d = disp(la, lo, t) * R;
      let x = d * Math.cos(la) * Math.cos(lo);
      let y = d * Math.sin(la);
      let z = d * Math.cos(la) * Math.sin(lo);
      // rotate Y
      const cy1 = Math.cos(rotY), sy1 = Math.sin(rotY);
      [x, z] = [x * cy1 - z * sy1, x * sy1 + z * cy1];
      // rotate X
      const cx1 = Math.cos(tiltX), sx1 = Math.sin(tiltX);
      [y, z] = [y * cx1 - z * sx1, y * sx1 + z * cx1];
      const p = 3.2 * R / (3.2 * R - z);
      return { x: cx + x * p, y: cy + y * p, z };
    };

    const draw = (time: number) => {
      const t = time / 1000;
      ctx.clearRect(0, 0, w, h);
      const R = Math.min(w, h) * 0.34;
      const cx = w / 2, cy = h * 0.45;

      // platform rings
      ctx.save();
      ctx.translate(cx, cy + R * 1.32);
      ctx.scale(1, 0.22);
      for (let i = 0; i < 4; i++) {
        ctx.beginPath();
        const rr = R * (0.55 + i * 0.16);
        const a0 = t * (i % 2 ? -0.3 : 0.25) + i;
        ctx.setLineDash(i === 1 ? [4, 8] : i === 3 ? [R * 0.6, R * 0.25] : []);
        ctx.arc(0, 0, rr, a0, a0 + Math.PI * (i === 0 ? 2 : 1.6));
        ctx.strokeStyle = `rgba(${color},${0.5 - i * 0.1})`;
        ctx.lineWidth = i === 0 ? 1.5 : 1;
        ctx.stroke();
      }
      ctx.restore();
      ctx.setLineDash([]);

      // mesh
      const seg = (pts: { x: number; y: number; z: number }[]) => {
        for (let i = 0; i < pts.length - 1; i++) {
          const a = pts[i], b = pts[i + 1];
          const depth = ((a.z + b.z) / 2 / R + 1) / 2; // 0 back … 1 front
          ctx.strokeStyle = `rgba(${color},${0.08 + depth * 0.62})`;
          ctx.lineWidth = 0.6 + depth * 0.7;
          ctx.beginPath(); ctx.moveTo(a.x, a.y); ctx.lineTo(b.x, b.y); ctx.stroke();
        }
      };
      for (let i = 1; i < LAT; i++) {
        const la = -Math.PI / 2 + (i / LAT) * Math.PI;
        const pts = [];
        for (let j = 0; j <= LON * 2; j++) pts.push(project(la, (j / (LON * 2)) * Math.PI * 2, t, R, cx, cy));
        seg(pts);
      }
      for (let j = 0; j < LON; j++) {
        const lo = (j / LON) * Math.PI * 2;
        const pts = [];
        for (let i = 0; i <= LAT * 2; i++) pts.push(project(-Math.PI / 2 + (i / (LAT * 2)) * Math.PI, lo, t, R, cx, cy));
        seg(pts);
      }

      // orbit + satellite marker
      const oa = t * 0.5;
      ctx.beginPath();
      ctx.ellipse(cx, cy, R * 1.28, R * 0.32, -0.32, 0, Math.PI * 2);
      ctx.strokeStyle = `rgba(${color},0.22)`; ctx.lineWidth = 1; ctx.stroke();
      const sx = cx + Math.cos(oa) * R * 1.28 * Math.cos(-0.32) - Math.sin(oa) * R * 0.32 * Math.sin(-0.32);
      const sy = cy + Math.cos(oa) * R * 1.28 * Math.sin(-0.32) + Math.sin(oa) * R * 0.32 * Math.cos(-0.32);
      ctx.fillStyle = `rgba(${color},1)`; ctx.beginPath(); ctx.arc(sx, sy, 3, 0, Math.PI * 2); ctx.fill();
      ctx.strokeStyle = `rgba(${color},0.5)`; ctx.beginPath(); ctx.arc(sx, sy, 8, 0, Math.PI * 2); ctx.stroke();
    };

    let last = performance.now();
    const loop = (now: number) => {
      const dt = Math.min(0.05, (now - last) / 1000); last = now;
      if (visible) {
        boost += (targetBoost - boost) * 0.05;
        tiltX += (targetTiltX - tiltX) * 0.04;
        rotY += dt * 0.25 + boost;
        draw(now);
      }
      raf = requestAnimationFrame(loop);
    };
    if (reduce) draw(0); else raf = requestAnimationFrame(loop);

    return () => { cancelAnimationFrame(raf); ro.disconnect(); io.disconnect(); window.removeEventListener("pointermove", onMove); };
  }, [color]);

  return <canvas ref={ref} className={className} aria-hidden />;
}
