import type { Project } from "@/data/types";
import { seeded } from "@/lib/random";
import { cn } from "@/lib/utils";

const BOX: Record<Project["ratio"], [number, number]> = {
  square: [400, 400],
  portrait: [400, 500],
  landscape: [600, 400],
  tall: [400, 620],
};

/**
 * Project cover. Uses `project.cover` when provided; otherwise generates a
 * black-and-white typographic artwork in the style of the project type, so the
 * grid reads as a real portfolio until the actual files are uploaded.
 */
export function Artwork({ project, className }: { project: Project; className?: string }) {
  if (project.cover) {
    return (
      // eslint-disable-next-line @next/next/no-img-element
      <img src={project.cover} alt={project.title} loading="lazy" className={cn("h-full w-full object-cover", className)} />
    );
  }
  const [W, H] = BOX[project.ratio];
  const r = seeded(project.slug);
  const t = project.title.toUpperCase();
  const F = "Archivo Variable";
  const M = "JetBrains Mono";

  let art: React.ReactNode;
  switch (project.type) {
    case "Matchday": {
      const [a, b] = t.includes("×") ? t.split("×").map((s) => s.trim().slice(0, 3)) : ["DOM", "OPP"];
      art = (
        <>
          <rect width={W} height={H} fill="#0a0a0a" />
          {Array.from({ length: 14 }, (_, i) => (
            <line key={i} x1={(i * W) / 13} y1="0" x2={(i * W) / 13} y2={H} stroke="#fff" strokeOpacity="0.06" />
          ))}
          <text x="24" y="44" fontFamily={M} fontSize="11" fill="#fff" fillOpacity=".6" letterSpacing="2">MATCHDAY · {project.year}</text>
          <text x="24" y={H * 0.5} fontFamily={F} fontWeight={700} fontSize={W * 0.26} letterSpacing="-6" fill="#fff">{a}</text>
          <text x={W - 24} y={H * 0.5 + W * 0.24} textAnchor="end" fontFamily={F} fontWeight={700} fontSize={W * 0.26} letterSpacing="-6" fill="#0a0a0a" stroke="#fff" strokeWidth="2.4" paintOrder="stroke">{b}</text>
          <line x1="24" y1={H - 70} x2={W - 24} y2={H - 70} stroke="#fff" strokeOpacity=".4" />
          <text x="24" y={H - 44} fontFamily={F} fontWeight={600} fontSize="15" fill="#fff" letterSpacing="1">{project.campaign.toUpperCase()}</text>
          <text x={W - 24} y={H - 44} textAnchor="end" fontFamily={M} fontSize="11" fill="#fff" fillOpacity=".6">20:30 · KICK-OFF</text>
        </>
      );
      break;
    }
    case "Anúncio de jogador": {
      const name = project.title.replace(/^(Welcome,|Renovação —)\s*/i, "").toUpperCase();
      art = (
        <>
          <rect width={W} height={H} fill="#f4f4f2" />
          <rect x={W * 0.52} y="0" width={W * 0.48} height={H} fill="#0a0a0a" />
          <text x={W * 0.76} y={H * 0.62} textAnchor="middle" fontFamily={F} fontWeight={700} fontSize={H * 0.5} fill="#0a0a0a" stroke="#808080" strokeWidth="2" paintOrder="stroke" letterSpacing="-10">{String(Math.floor(r() * 30) + 1).padStart(2, "0")}</text>
          <text x="24" y="44" fontFamily={M} fontSize="11" fill="#0a0a0a" fillOpacity=".55" letterSpacing="2">OFFICIAL · {project.year}</text>
          <text x="24" y={H * 0.42} fontFamily={F} fontWeight={700} fontSize={W * 0.068} letterSpacing="-1.5" fill="#0a0a0a">{t.startsWith("WELCOME") ? "WELCOME" : "RENOVADO"}</text>
          <text x="24" y={H * 0.42 + W * 0.06} fontFamily={F} fontWeight={300} fontSize={W * 0.042} fill="#0a0a0a">{name}</text>
          <text x="24" y={H - 28} fontFamily={M} fontSize="10" fill="#0a0a0a" fillOpacity=".55" letterSpacing="2">{project.campaign.toUpperCase()}</text>
        </>
      );
      break;
    }
    case "Motion": {
      art = (
        <>
          <rect width={W} height={H} fill="#0a0a0a" />
          {Array.from({ length: 9 }, (_, i) => {
            const a = (Math.PI / 2) * (i / 8);
            const L = Math.min(W, H) * (0.9 - i * 0.03);
            return (
              <line key={i} x1={W * 0.18} y1={H * 0.82} x2={W * 0.18 + Math.cos(a) * L} y2={H * 0.82 - Math.sin(a) * L} stroke="#fff" strokeWidth={i % 2 ? 1 : 3} strokeOpacity={0.25 + (i % 3) * 0.25} />
            );
          })}
          <circle cx={W / 2} cy={H / 2} r="30" fill="none" stroke="#fff" />
          <path d={`M${W / 2 - 8} ${H / 2 - 12} L${W / 2 + 14} ${H / 2} L${W / 2 - 8} ${H / 2 + 12} Z`} fill="#fff" />
          <text x="24" y="44" fontFamily={M} fontSize="11" fill="#fff" fillOpacity=".6" letterSpacing="2">MOTION · 00:15</text>
          <text x={W - 24} y={H - 28} textAnchor="end" fontFamily={F} fontWeight={700} fontSize={W * 0.08} fill="#fff" letterSpacing="-1">{t}</text>
        </>
      );
      break;
    }
    case "Carrossel": {
      const n = 3;
      art = (
        <>
          <rect width={W} height={H} fill="#f4f4f2" />
          {Array.from({ length: n }, (_, i) => {
            const pw = (W - 48 - (n - 1) * 8) / n;
            const x = 24 + i * (pw + 8);
            const dark = i === 1;
            return (
              <g key={i}>
                <rect x={x} y={H * 0.18} width={pw} height={H * 0.64} fill={dark ? "#0a0a0a" : "#fff"} stroke="#0a0a0a" strokeOpacity=".15" />
                <text x={x + pw / 2} y={H * 0.56} textAnchor="middle" fontFamily={F} fontWeight={700} fontSize={pw * 0.5} fill={dark ? "#fff" : "#0a0a0a"} letterSpacing="-3">{Math.floor(r() * 90) + 10}</text>
                <text x={x + 10} y={H * 0.18 + 18} fontFamily={M} fontSize="9" fill={dark ? "#fff" : "#0a0a0a"} fillOpacity=".6">{String(i + 1).padStart(2, "0")}/08</text>
                <rect x={x + 10} y={H * 0.72} width={pw * (0.3 + r() * 0.5)} height="3" fill={dark ? "#fff" : "#0a0a0a"} />
              </g>
            );
          })}
          <text x="24" y="40" fontFamily={M} fontSize="11" fill="#0a0a0a" fillOpacity=".55" letterSpacing="2">CARROSSEL · 08 SLIDES</text>
          <text x="24" y={H - 26} fontFamily={F} fontWeight={600} fontSize="15" fill="#0a0a0a">{t}</text>
        </>
      );
      break;
    }
    case "Campanha editorial": {
      art = (
        <>
          <rect width={W} height={H} fill="#ffffff" />
          <rect x={W * 0.3} y={H * 0.12} width={W * 0.62} height={H * 0.62} fill="#e9e9e6" />
          <rect x={W * 0.3} y={H * 0.12} width={W * 0.62} height={H * 0.62} fill="url(#ed-g)" />
          <line x1="24" y1={H * 0.8} x2={W - 24} y2={H * 0.8} stroke="#0a0a0a" />
          <text x="24" y={H * 0.8 + 40} fontFamily={F} fontWeight={700} fontSize={W * 0.085} letterSpacing="-2" fill="#0a0a0a">{t}</text>
          <text x="24" y={H * 0.12 + 10} fontFamily={M} fontSize="10" fill="#0a0a0a" fillOpacity=".55" letterSpacing="2" writingMode="vertical-rl">EDITORIAL · {project.year}</text>
          <defs>
            <radialGradient id="ed-g" cx="50%" cy="35%" r="60%">
              <stop offset="0" stopColor="#fff" stopOpacity=".9" />
              <stop offset="1" stopColor="#0a0a0a" stopOpacity=".12" />
            </radialGradient>
          </defs>
        </>
      );
      break;
    }
    default: {
      const cols = 12;
      const s = (W - 48) / cols;
      const rows = Math.floor((H - 100) / s);
      art = (
        <>
          <rect width={W} height={H} fill="#ffffff" />
          {Array.from({ length: cols * rows }, (_, k) => {
            const v = r();
            const sz = s * (0.15 + v * 0.75);
            const x = 24 + (k % cols) * s + (s - sz) / 2;
            const y = 60 + Math.floor(k / cols) * s + (s - sz) / 2;
            return <rect key={k} x={x} y={y} width={sz} height={sz} fill="#0a0a0a" fillOpacity={0.15 + v * 0.85} />;
          })}
          <text x="24" y="40" fontFamily={M} fontSize="11" fill="#0a0a0a" fillOpacity=".55" letterSpacing="2">LAB · {t}</text>
        </>
      );
    }
  }

  return (
    <svg
      viewBox={`0 0 ${W} ${H}`}
      preserveAspectRatio="xMidYMid slice"
      className={cn("block h-full w-full", className)}
      role="img"
      aria-label={`${project.title} — ${project.type}`}
    >
      {art}
    </svg>
  );
}

export const ratioClass: Record<Project["ratio"], string> = {
  square: "aspect-square",
  portrait: "aspect-[4/5]",
  landscape: "aspect-[3/2]",
  tall: "aspect-[2/3]",
};
