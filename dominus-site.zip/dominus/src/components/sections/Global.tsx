"use client";
import { AnimatePresence, motion } from "framer-motion";
import { useMemo, useState } from "react";
import { Counter } from "@/components/ui/Counter";
import { Brackets, DemoBadge, SectionHead } from "@/components/ui/Primitives";
import { Reveal } from "@/components/ui/Reveal";
import { SplitText } from "@/components/ui/SplitText";
import type { Milestone } from "@/data/types";
import type { MapData } from "@/lib/worldDots";
import { cn } from "@/lib/utils";

const W = 1000, H = 500;
const ROLE = { hub: "Base", active: "Ativo", prospect: "Em expansão" } as const;

export function Global({
  map,
  milestones,
  reach,
  demo,
}: {
  map: MapData;
  milestones: Milestone[];
  reach: { label: string; value: number; suffix?: string; decimals?: number }[];
  demo: boolean;
}) {
  const years = useMemo(() => Array.from(new Set(milestones.map((m) => m.year))).sort(), [milestones]);
  const [year, setYear] = useState(years[years.length - 1] ?? new Date().getFullYear());
  const [sel, setSel] = useState<string | null>(map.markets.find((m) => m.role === "hub")?.id ?? null);
  const hub = map.markets.find((m) => m.role === "hub");
  const market = map.markets.find((m) => m.id === sel);
  const visible = (since: number) => since <= year;

  return (
    <section id="global" className="relative border-t hairline py-24 md:py-36">
      <div className="mx-auto max-w-[1600px] px-5 md:px-10">
        <SectionHead index="05" name="Global Connections" coord="N 51°30′ · W 00°07′" />
        <div className="mt-10 grid gap-8 md:mt-14 md:grid-cols-12">
          <SplitText className="display text-[length:var(--text-giant)] md:col-span-8" lines={["Global", "Connections"]} />
          <Reveal className="md:col-span-4 md:self-end">
            <p className="text-lg leading-snug text-graphite">Mercados, competições e conexões. Use a linha do tempo para ver a expansão ano a ano e toque num ponto para ver detalhes.</p>
            {demo && <DemoBadge className="mt-4" />}
          </Reveal>
        </div>

        {/* ── Map ─────────────────────────────────────────────── */}
        <div className="relative mt-14 grid gap-px border border-ink bg-ink md:grid-cols-12">
          <div className="relative overflow-hidden bg-paper md:col-span-9">
            <div className="absolute left-4 top-4 z-10 flex items-center gap-3">
              <span className="label">World · Natural Earth</span>
              <span className="label tabular-nums text-ash">{year}</span>
            </div>
            <svg viewBox={`0 0 ${W} ${H}`} className="block h-auto w-full" role="img" aria-label="Mapa de mercados DOMINUS">
              {map.dots.map(([x, y, id], k) => {
                const m = id ? map.markets.find((mm) => mm.id === id) : undefined;
                const on = m && visible(m.since);
                return (
                  <circle key={k} cx={x} cy={y} r={on ? 2 : 1.3}
                    className={cn("transition-[fill,opacity] duration-700", on ? (sel === id ? "fill-ink" : "fill-ink/70") : "fill-ink/20")} />
                );
              })}
              {/* arcs from hub */}
              {hub && map.markets.filter((m) => m.id !== hub.id).map((m) => {
                const mx = (hub.x + m.x) / 2, my = Math.min(hub.y, m.y) - Math.abs(hub.x - m.x) * 0.28 - 20;
                const d = `M${hub.x} ${hub.y} Q${mx} ${my} ${m.x} ${m.y}`;
                const on = visible(m.since);
                return (
                  <g key={m.id}>
                    {m.role === "prospect" ? (
                      <path d={d} fill="none" stroke="#0a0a0a" strokeWidth={sel === m.id ? 1.4 : 1} strokeOpacity={on ? 0.5 : 0.08}
                        strokeDasharray="3 5" className={cn("transition-[stroke-opacity] duration-700", on && "dash-flow")} />
                    ) : (
                      <motion.path d={d} fill="none" stroke="#0a0a0a" strokeWidth={sel === m.id ? 1.8 : 1.2} strokeOpacity={on ? 0.85 : 0.08}
                        initial={{ pathLength: 0 }} whileInView={{ pathLength: 1 }} viewport={{ once: true }} transition={{ duration: 1.8, ease: [0.16, 1, 0.3, 1] }} />
                    )}
                  </g>
                );
              })}
              {map.markets.map((m) => {
                const on = visible(m.since);
                const isSel = sel === m.id;
                return (
                  <g key={m.id} transform={`translate(${m.x} ${m.y})`} className="cursor-pointer" onClick={() => setSel(m.id)} onMouseEnter={() => setSel(m.id)}
                    role="button" tabIndex={0} aria-label={`${m.country} — ${ROLE[m.role]}`} onKeyDown={(e) => (e.key === "Enter" || e.key === " ") && setSel(m.id)} opacity={on ? 1 : 0.3}>
                    <circle r="16" fill="transparent" />
                    {on && <circle r="5" fill="none" stroke="#0a0a0a"><animate attributeName="r" values="5;16" dur="2.2s" repeatCount="indefinite" /><animate attributeName="opacity" values=".7;0" dur="2.2s" repeatCount="indefinite" /></circle>}
                    <circle r={m.role === "hub" ? 6 : 4.5} fill={isSel || m.role === "hub" ? "#0a0a0a" : "#fff"} stroke="#0a0a0a" strokeWidth="1.5" />
                    {(isSel || m.role === "hub") && (
                      <g>
                        <line x1="6" y1="-6" x2="22" y2="-22" stroke="#0a0a0a" />
                        <rect x="22" y="-34" width={m.country.length * 7.4 + 14} height="20" fill="#0a0a0a" />
                        <text x="29" y="-20" fontFamily="JetBrains Mono" fontSize="10" fill="#fff" letterSpacing="1">{m.country.toUpperCase()}</text>
                      </g>
                    )}
                  </g>
                );
              })}
            </svg>
            <div className="flex flex-wrap gap-5 border-t hairline px-4 py-3">
              <span className="label flex items-center gap-2"><span className="h-2.5 w-2.5 rounded-full bg-ink" /> Base</span>
              <span className="label flex items-center gap-2"><span className="h-2.5 w-2.5 rounded-full border-[1.5px] border-ink" /> Ativo</span>
              <span className="label flex items-center gap-2"><span className="w-5 border-t border-dashed border-ink" /> Em expansão</span>
            </div>
          </div>

          {/* detail panel */}
          <div className="relative bg-paper p-5 md:col-span-3">
            <Brackets className="m-2" />
            <AnimatePresence mode="wait">
              {market ? (
                <motion.div key={market.id} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }} transition={{ duration: 0.35 }} className="flex h-full flex-col gap-6">
                  <div>
                    <span className="label text-ash">{ROLE[market.role]} · desde {market.since}</span>
                    <h3 className="mt-2 text-3xl font-semibold uppercase tracking-[-0.02em]">{market.country}</h3>
                    <p className="mt-2 text-sm text-graphite">{market.note}</p>
                  </div>
                  <div>
                    <span className="label text-ash">Competições do mercado</span>
                    <ul className="mt-2 space-y-1.5">
                      {market.competitions.map((c) => (<li key={c} className="flex items-center gap-2 text-sm"><span className="h-1 w-1 bg-ink" />{c}</li>))}
                    </ul>
                  </div>
                  <div className="mt-auto font-mono text-[10px] leading-relaxed tracking-wider text-ash">
                    LAT {market.coords[1].toFixed(2)}<br />LON {market.coords[0].toFixed(2)}
                  </div>
                </motion.div>
              ) : <p className="label text-ash">Selecione um ponto no mapa</p>}
            </AnimatePresence>
          </div>
        </div>

        {/* ── Reach ───────────────────────────────────────────── */}
        <div className="mt-16 grid grid-cols-2 gap-px border-y border-ink bg-line md:grid-cols-4">
          {reach.map((r) => (
            <div key={r.label} className="bg-paper py-8 pr-4">
              <Counter value={r.value} decimals={r.decimals} suffix={r.suffix} className="block text-5xl font-semibold tabular-nums tracking-[-0.04em] md:text-7xl" />
              <span className="label mt-3 block text-graphite">{r.label}</span>
            </div>
          ))}
        </div>

        {/* ── The Timeline ────────────────────────────────────── */}
        <div className="mt-24">
          <div className="flex flex-col justify-between gap-4 md:flex-row md:items-end">
            <div>
              <p className="label text-ash">Exclusive · The Timeline</p>
              <h3 className="display mt-4 text-[length:var(--text-display)]">Marcos e expansão.</h3>
            </div>
            <div className="flex gap-2" role="tablist" aria-label="Ano">
              {years.map((y) => (
                <button key={y} role="tab" aria-selected={y === year} onClick={() => setYear(y)}
                  className={cn("label rounded-full border px-4 py-2 tabular-nums transition-colors", y === year ? "border-ink bg-ink text-white" : "border-ink/20 hover:border-ink")}>
                  {y}
                </button>
              ))}
            </div>
          </div>
          <div className="relative mt-12 overflow-x-auto pb-4 [scrollbar-width:thin]" data-lenis-prevent-wheel>
            <div className="relative flex min-w-[900px] items-start">
              <div className="absolute left-0 right-0 top-[9px] h-px bg-line" />
              {milestones.map((m, k) => {
                const on = m.year <= year;
                return (
                  <button key={k} onClick={() => { setYear(m.year); if (m.marketId) setSel(m.marketId); }}
                    className="group relative flex flex-1 flex-col items-start pr-6 text-left" data-cursor="hover">
                    <span className={cn("relative z-10 block h-[19px] w-[19px] rounded-full border border-ink transition-colors", on ? "bg-ink" : "bg-paper")}>
                      {m.year === year && <span className="absolute inset-[-6px] rounded-full border border-ink/40" />}
                    </span>
                    <span className="label mt-5 block tabular-nums text-ash">{m.year}{m.quarter ? ` · ${m.quarter}` : ""}</span>
                    <span className={cn("mt-2 block text-lg font-semibold uppercase leading-tight transition-colors", on ? "text-ink" : "text-ash")}>{m.title}</span>
                    <span className="mt-2 block max-w-[220px] text-sm leading-relaxed text-graphite">{m.description}</span>
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
