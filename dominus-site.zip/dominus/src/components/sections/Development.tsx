"use client";
import { AnimatePresence, motion } from "framer-motion";
import { useEffect, useRef, useState } from "react";
import { SectionHead } from "@/components/ui/Primitives";
import { SplitText } from "@/components/ui/SplitText";

const CHAPTERS = [
  {
    t: "Digital Identity",
    k: "Identidade digital",
    d: "Construímos uma imagem consistente e reconhecível: assinatura visual, tratamento de foto, tipografia e tom de voz. Um atleta que se reconhece em cada peça — e que é reconhecido em cada feed.",
    points: ["Assinatura visual", "Direção de fotografia", "Tom de voz"],
  },
  {
    t: "Strategic Positioning",
    k: "Posicionamento estratégico",
    d: "Definimos onde o atleta está e onde quer chegar no ambiente digital do esporte. Mapeamos público, mercado e referências para dar direção a cada publicação.",
    points: ["Análise de perfil", "Mapa de mercado", "Narrativa"],
  },
  {
    t: "Content Planning",
    k: "Planejamento de conteúdo",
    d: "Organizamos o conteúdo em calendário — pré-jogo, matchday, pós-jogo, bastidores e marcos de carreira — para aumentar visibilidade e melhorar a comunicação.",
    points: ["Calendário editorial", "Formatos por plataforma", "Rotina de publicação"],
  },
  {
    t: "Professional Presentations",
    k: "Apresentações profissionais",
    d: "Criamos materiais visuais para clubes, agentes e oportunidades: apresentações de atleta, scouting reports visuais e perfis prontos para negociação.",
    points: ["Athlete deck", "Perfil para clubes", "Relatórios visuais"],
  },
];

export function Development() {
  const [active, setActive] = useState(0);
  const refs = useRef<(HTMLDivElement | null)[]>([]);

  useEffect(() => {
    const io = new IntersectionObserver(
      (es) => es.forEach((e) => { if (e.isIntersecting) setActive(Number((e.target as HTMLElement).dataset.i)); }),
      { rootMargin: "-45% 0px -45% 0px" },
    );
    refs.current.forEach((r) => r && io.observe(r));
    return () => io.disconnect();
  }, []);

  return (
    <section id="services" className="relative py-24 md:py-36">
      <div className="mx-auto max-w-[1600px] px-5 md:px-10">
        <SectionHead index="04" name="Player Development" coord="S 23°33′ · W 46°38′" />
        <div className="mt-10 md:mt-14">
          <SplitText className="display text-[length:var(--text-giant)]" lines={["Player", "Development"]} />
        </div>

        <div className="mt-16 grid gap-10 md:mt-24 md:grid-cols-12">
          {/* sticky visual */}
          <div className="hidden md:col-span-6 md:block">
            <div className="sticky top-28">
              <div className="relative aspect-square overflow-hidden border border-ink bg-paper">
                <div className="absolute inset-0 bg-grid-fine" />
                <div className="absolute left-5 top-5 flex items-baseline gap-3">
                  <span className="label">Chapter</span>
                  <span className="font-mono text-sm tabular-nums">{String(active + 1).padStart(2, "0")}/04</span>
                </div>
                <AnimatePresence mode="wait">
                  <motion.div key={active} className="absolute inset-0" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} transition={{ duration: 0.4 }}>
                    <ChapterVisual i={active} />
                  </motion.div>
                </AnimatePresence>
                <div className="absolute bottom-0 left-0 right-0 flex">
                  {CHAPTERS.map((c, i) => (
                    <div key={c.t} className="h-1 flex-1 bg-line">
                      <motion.div className="h-1 bg-ink" animate={{ width: i <= active ? "100%" : "0%" }} transition={{ duration: 0.6 }} />
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* chapters */}
          <div className="md:col-span-6 md:pl-8">
            {CHAPTERS.map((c, i) => (
              <div key={c.t} ref={(el) => { refs.current[i] = el; }} data-i={i} className="flex min-h-[70vh] flex-col justify-center border-t hairline py-12 first:border-t-0 md:py-0">
                <div className="mb-8 aspect-square border border-ink md:hidden"><ChapterVisual i={i} /></div>
                <span className="font-mono text-7xl font-light tabular-nums text-ink/15 md:text-8xl">{String(i + 1).padStart(2, "0")}</span>
                <p className="label mt-4 text-ash">{c.k}</p>
                <h3 className="display mt-3 text-[clamp(2.2rem,4vw,4rem)]">{c.t}</h3>
                <p className="mt-6 max-w-lg text-lg leading-relaxed text-graphite">{c.d}</p>
                <ul className="mt-8 flex flex-wrap gap-2">
                  {c.points.map((p) => (<li key={p} className="label rounded-full border border-ink/20 px-3 py-1.5">{p}</li>))}
                </ul>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}

const draw = (d = 0) => ({ initial: { pathLength: 0 }, animate: { pathLength: 1 }, transition: { duration: 1.2, delay: d, ease: [0.16, 1, 0.3, 1] as const } });

function ChapterVisual({ i }: { i: number }) {
  const S = "#0a0a0a";
  if (i === 0)
    return (
      <svg viewBox="0 0 400 400" className="h-full w-full">
        <motion.circle cx="200" cy="200" r="120" fill="none" stroke={S} strokeOpacity=".25" {...draw()} />
        <motion.circle cx="200" cy="200" r="80" fill="none" stroke={S} strokeOpacity=".25" strokeDasharray="3 5" {...draw(0.1)} />
        <motion.line x1="40" y1="200" x2="360" y2="200" stroke={S} strokeOpacity=".2" {...draw(0.2)} />
        <motion.line x1="200" y1="40" x2="200" y2="360" stroke={S} strokeOpacity=".2" {...draw(0.2)} />
        <motion.path d="M150 150 L150 250 L195 250 Q250 250 250 200 Q250 150 195 150 Z" fill="none" stroke={S} strokeWidth="6" {...draw(0.3)} />
        <motion.rect x="150" y="270" width="100" height="4" fill={S} initial={{ scaleX: 0 }} animate={{ scaleX: 1 }} transition={{ delay: 0.9, duration: 0.6 }} style={{ transformOrigin: "150px 272px" }} />
        <text x="200" y="300" textAnchor="middle" fontFamily="JetBrains Mono" fontSize="9" letterSpacing="2" fill={S} fillOpacity=".6">MONOGRAM · GRID 8PT</text>
      </svg>
    );
  if (i === 1)
    return (
      <svg viewBox="0 0 400 400" className="h-full w-full">
        <motion.line x1="60" y1="200" x2="340" y2="200" stroke={S} {...draw()} />
        <motion.line x1="200" y1="60" x2="200" y2="340" stroke={S} {...draw(0.1)} />
        <text x="340" y="190" textAnchor="end" fontFamily="JetBrains Mono" fontSize="9" fill={S} fillOpacity=".6">ALCANCE →</text>
        <text x="206" y="70" fontFamily="JetBrains Mono" fontSize="9" fill={S} fillOpacity=".6">↑ RELEVÂNCIA</text>
        {[[110, 260], [150, 230], [130, 290], [250, 250], [270, 160], [160, 150], [300, 280], [90, 130]].map(([x, y], k) => (
          <motion.circle key={k} cx={x} cy={y} r="5" fill={S} fillOpacity=".25" initial={{ scale: 0 }} animate={{ scale: 1 }} transition={{ delay: 0.3 + k * 0.05 }} />
        ))}
        <motion.path d="M140 270 C 200 230, 250 160, 290 110" fill="none" stroke={S} strokeDasharray="4 4" {...draw(0.6)} />
        <motion.circle cx="290" cy="110" r="9" fill={S} initial={{ scale: 0 }} animate={{ scale: 1 }} transition={{ delay: 1.4 }} />
        <motion.circle cx="290" cy="110" r="20" fill="none" stroke={S} initial={{ scale: 0 }} animate={{ scale: 1 }} transition={{ delay: 1.5 }} />
        <text x="290" y="85" textAnchor="middle" fontFamily="JetBrains Mono" fontSize="9" fill={S}>TARGET</text>
      </svg>
    );
  if (i === 2)
    return (
      <svg viewBox="0 0 400 400" className="h-full w-full">
        {["S", "T", "Q", "Q", "S", "S", "D"].map((d, k) => (
          <text key={k} x={70 + k * 40} y="90" textAnchor="middle" fontFamily="JetBrains Mono" fontSize="10" fill={S} fillOpacity=".6">{d}</text>
        ))}
        {Array.from({ length: 28 }, (_, k) => {
          const x = 52 + (k % 7) * 40, y = 105 + Math.floor(k / 7) * 52;
          const kind = [3, 6, 10, 13, 17, 20, 24, 27].includes(k) ? 2 : [1, 8, 15, 22].includes(k) ? 1 : 0;
          return (
            <motion.rect key={k} x={x} y={y} width="36" height="46" fill={kind === 2 ? S : "none"} fillOpacity={kind === 2 ? 1 : 0} stroke={S} strokeOpacity={kind ? 1 : 0.2}
              initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: k * 0.025 }} />
          );
        })}
        <text x="52" y="340" fontFamily="JetBrains Mono" fontSize="9" fill={S} fillOpacity=".6">■ MATCHDAY   □ BASTIDORES</text>
      </svg>
    );
  return (
    <svg viewBox="0 0 400 400" className="h-full w-full">
      {[0, 1, 2].map((k) => (
        <motion.g key={k} initial={{ y: 30, opacity: 0 }} animate={{ y: 0, opacity: 1 }} transition={{ delay: k * 0.15, duration: 0.7 }}>
          <rect x={90 + k * 22} y={90 + k * 22} width="200" height="140" fill={k === 2 ? S : "#fff"} stroke={S} />
          {k === 2 && (
            <>
              <text x={130} y={170} fontFamily="Archivo Variable" fontWeight={700} fontSize="26" fill="#fff" letterSpacing="-1">ATHLETE</text>
              <text x={130} y={196} fontFamily="Archivo Variable" fontWeight={300} fontSize="20" fill="#fff">PROFILE</text>
              <text x={130} y={145} fontFamily="JetBrains Mono" fontSize="8" fill="#fff" fillOpacity=".6">FOR CLUBS & AGENTS</text>
              <rect x={130} y={240} width="120" height="2" fill="#fff" />
            </>
          )}
        </motion.g>
      ))}
      <text x="200" y="350" textAnchor="middle" fontFamily="JetBrains Mono" fontSize="9" letterSpacing="2" fill={S} fillOpacity=".6">DECK · 12 SLIDES · PDF</text>
    </svg>
  );
}
