"use client";
import { AnimatePresence, motion } from "framer-motion";
import { ArrowUpRight, Plus, X } from "lucide-react";
import Link from "next/link";
import { useMemo, useState } from "react";
import { AthleteCard } from "@/components/athletes/AthleteCard";
import { scrollToId } from "@/components/layout/Providers";
import { Counter } from "@/components/ui/Counter";
import { DemoBadge, SectionHead } from "@/components/ui/Primitives";
import { Reveal } from "@/components/ui/Reveal";
import { SplitText } from "@/components/ui/SplitText";
import { AthleteVisual } from "@/components/visuals/AthleteVisual";
import type { Athlete } from "@/data/types";
import { cn } from "@/lib/utils";

type Key = "position" | "nationality" | "category" | "club";
const FILTERS: { key: Key; label: string }[] = [
  { key: "position", label: "Posição" },
  { key: "nationality", label: "País" },
  { key: "category", label: "Categoria" },
  { key: "club", label: "Clube" },
];

export function Athletes({ athletes, featured }: { athletes: Athlete[]; featured?: { athlete: Athlete; month: string } }) {
  const [sel, setSel] = useState<Partial<Record<Key, string>>>({});
  const [open, setOpen] = useState<Key | null>(null);

  const options = useMemo(() => {
    const o = {} as Record<Key, string[]>;
    FILTERS.forEach(({ key }) => (o[key] = Array.from(new Set(athletes.map((a) => a[key] as string))).sort()));
    return o;
  }, [athletes]);

  const list = athletes.filter((a) => FILTERS.every(({ key }) => !sel[key] || a[key] === sel[key]));
  const active = Object.values(sel).filter(Boolean).length;
  const emerging = athletes.filter((a) => a.emerging);

  return (
    <section id="athletes" className="relative py-24 md:py-36">
      <div className="mx-auto max-w-[1600px] px-5 md:px-10">
        <SectionHead index="02" name="Athlete Universe" coord="N 40°25′ · W 03°42′" />

        <div className="mt-10 grid gap-8 md:mt-14 md:grid-cols-12">
          <SplitText className="display text-[length:var(--text-giant)] md:col-span-8" lines={["Athlete", "Universe"]} />
          <Reveal className="md:col-span-4 md:self-end">
            <p className="text-lg leading-snug text-graphite">
              O diretório de atletas DOMINUS®. Perfis, números, trajetória e imagem — organizados para clubes, agentes e parceiros.
            </p>
          </Reveal>
        </div>

        {/* ── Athlete of the Month ─────────────────────────────── */}
        {featured && <AthleteOfTheMonth athlete={featured.athlete} month={featured.month} />}

        {/* ── Filters ──────────────────────────────────────────── */}
        <div className="sticky top-[60px] z-20 -mx-5 mt-20 border-y hairline bg-paper/90 px-5 py-3 backdrop-blur md:-mx-10 md:px-10" role="group" aria-label="Filtrar atletas">
          <div className="flex flex-wrap items-center gap-2">
            <span className="label mr-2 hidden text-ash md:inline">Filtrar</span>
            {FILTERS.map(({ key, label }) => (
              <div key={key} className="relative">
                <button
                  onClick={() => setOpen(open === key ? null : key)}
                  aria-expanded={open === key}
                  aria-haspopup="listbox"
                  className={cn(
                    "label flex items-center gap-2 rounded-full border px-3.5 py-2 transition-colors",
                    sel[key] ? "border-ink bg-ink text-white" : "border-ink/20 hover:border-ink",
                  )}
                >
                  {label}{sel[key] ? `: ${sel[key]}` : ""}
                  <Plus className={cn("h-3 w-3 transition-transform", open === key && "rotate-45")} />
                </button>
                <AnimatePresence>
                  {open === key && (
                    <motion.ul
                      role="listbox"
                      initial={{ opacity: 0, y: -6 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: -6 }}
                      transition={{ duration: 0.25 }}
                      className="absolute left-0 top-full z-30 mt-2 min-w-[200px] border border-ink bg-paper p-1 shadow-[0_20px_40px_-20px_rgba(0,0,0,0.25)]"
                    >
                      {["", ...options[key]].map((v) => (
                        <li key={v || "all"}>
                          <button
                            role="option"
                            aria-selected={(sel[key] ?? "") === v}
                            onClick={() => { setSel((s) => ({ ...s, [key]: v || undefined })); setOpen(null); }}
                            className={cn("label flex w-full items-center justify-between px-3 py-2 text-left hover:bg-bone", (sel[key] ?? "") === v && "bg-bone")}
                          >
                            {v || "Todos"}
                            <span className="text-ash">{v ? athletes.filter((a) => a[key] === v).length : athletes.length}</span>
                          </button>
                        </li>
                      ))}
                    </motion.ul>
                  )}
                </AnimatePresence>
              </div>
            ))}
            {active > 0 && (
              <button onClick={() => setSel({})} className="label flex items-center gap-1.5 px-2 py-2 text-graphite hover:text-ink">
                <X className="h-3 w-3" /> Limpar
              </button>
            )}
            <span className="label ml-auto tabular-nums text-ash" aria-live="polite">
              {String(list.length).padStart(2, "0")} / {String(athletes.length).padStart(2, "0")} perfis
            </span>
          </div>
        </div>

        {/* ── Grid ─────────────────────────────────────────────── */}
        <motion.div layout className="mt-10 grid grid-cols-2 gap-x-4 gap-y-12 md:grid-cols-3 md:gap-x-6 lg:grid-cols-4">
          <AnimatePresence mode="popLayout">
            {list.map((a) => (
              <AthleteCard key={a.slug} athlete={a} index={athletes.indexOf(a)} />
            ))}
            <motion.a
              layout
              key="register"
              href="#contact"
              onClick={(e) => { if (scrollToId("contact")) e.preventDefault(); }}
              data-cursor-label="Aplicar"
              className="group relative flex aspect-[3/4] flex-col justify-between border border-dashed border-ink/30 p-5 transition-colors hover:border-ink hover:bg-ink hover:text-white"
            >
              <span className="label text-ash group-hover:text-white/60">Próximo perfil</span>
              <span>
                <Plus className="mb-4 h-8 w-8" strokeWidth={1.2} />
                <span className="block text-xl font-semibold uppercase leading-tight">Seu perfil<br />aqui.</span>
                <span className="label mt-3 block text-graphite group-hover:text-white/60">Diretório aberto a novos atletas</span>
              </span>
            </motion.a>
          </AnimatePresence>
        </motion.div>
        {list.length === 0 && (
          <p className="mt-6 text-graphite">Nenhum atleta com essa combinação de filtros.</p>
        )}

        {/* ── Talent Showcase ──────────────────────────────────── */}
        {emerging.length > 0 && <TalentShowcase athletes={emerging} />}
      </div>
    </section>
  );
}

function AthleteOfTheMonth({ athlete, month }: { athlete: Athlete; month: string }) {
  return (
    <Reveal className="mt-20 md:mt-28">
      <div className="grid overflow-hidden border border-ink md:grid-cols-12">
        <div className="relative aspect-[4/5] md:col-span-5 md:aspect-auto md:min-h-[620px]">
          <AthleteVisual athlete={athlete} tone="dark" />
          <div className="scanline scanline-light" />
          <span className="label absolute left-5 top-5 bg-paper px-2 py-1">Athlete of the month</span>
        </div>
        <div className="relative flex flex-col justify-between gap-10 p-6 md:col-span-7 md:p-12">
          <div className="absolute inset-0 bg-grid-fine opacity-60" />
          <div className="relative flex items-center justify-between">
            <span className="label text-ash">{month}</span>
            {athlete.demo && <DemoBadge />}
          </div>
          <div className="relative">
            <p className="label mb-4">{athlete.position} · {athlete.club} · {athlete.nationality}</p>
            <h3 className="display text-[clamp(2.4rem,5.4vw,5.8rem)]">
              {athlete.name.split(" ").map((p, i) => (
                <span key={i} className={cn("block", i > 0 && "text-outline")}>{p}</span>
              ))}
            </h3>
            <p className="mt-6 max-w-lg text-lg leading-snug text-graphite">{athlete.bio}</p>
          </div>
          <div className="relative grid grid-cols-2 gap-px border-t border-ink bg-line md:grid-cols-4">
            {athlete.stats.season.map((s) => (
              <div key={s.label} className="bg-paper py-5 pr-4">
                <Counter value={s.value} suffix={s.suffix} className="block text-4xl font-semibold tabular-nums tracking-[-0.03em] md:text-5xl" />
                <span className="label mt-2 block text-graphite">{s.label}</span>
              </div>
            ))}
          </div>
          <Link href={`/atletas/${athlete.slug}/`} data-cursor="hover" className="relative inline-flex items-center gap-3 self-start border-b border-ink pb-1 text-sm font-semibold uppercase tracking-[0.12em]">
            Ver perfil completo <ArrowUpRight className="h-4 w-4" />
          </Link>
        </div>
      </div>
    </Reveal>
  );
}

function TalentShowcase({ athletes }: { athletes: Athlete[] }) {
  return (
    <div className="mt-28 bg-ink text-white md:mt-36">
      <div className="relative overflow-hidden p-6 md:p-12">
        <div className="absolute inset-0 bg-grid-dark" />
        <div className="relative flex flex-col justify-between gap-6 md:flex-row md:items-end">
          <div>
            <p className="label text-white/50">Exclusive · Talent Showcase</p>
            <h3 className="display mt-4 text-[clamp(2.4rem,5.5vw,5.5rem)]">Next<br /><span className="text-outline-light">generation.</span></h3>
          </div>
          <p className="max-w-sm text-white/65">Talentos emergentes acompanhados de perto pela DOMINUS® — apresentados para clubes e agentes antes de todo mundo.</p>
        </div>
        <ul className="relative mt-12 grid gap-px bg-white/15 md:grid-cols-3">
          {athletes.map((a, i) => (
            <li key={a.slug} className="bg-ink">
              <Link href={`/atletas/${a.slug}/`} data-cursor-label="Perfil" className="group flex items-center gap-5 p-5 transition-colors hover:bg-white hover:text-ink">
                <span className="font-mono text-4xl font-light tabular-nums text-white/30 group-hover:text-ink/30">{String(i + 1).padStart(2, "0")}</span>
                <span className="relative block h-20 w-16 shrink-0 overflow-hidden"><AthleteVisual athlete={a} tone="dark" showLabel={false} /></span>
                <span className="min-w-0">
                  <span className="block truncate text-lg font-semibold uppercase">{a.name}</span>
                  <span className="label mt-1 block text-white/50 group-hover:text-ink/60">{a.category} · {a.position}</span>
                  <span className="label block text-white/50 group-hover:text-ink/60">{a.club}</span>
                </span>
                <ArrowUpRight className="ml-auto h-5 w-5 shrink-0 transition-transform group-hover:rotate-45" />
              </Link>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}
