"use client";
import { AnimatePresence, motion, useScroll, useTransform } from "framer-motion";
import { useRef, useState } from "react";
import { ProjectModal } from "@/components/projects/ProjectModal";
import { ProjectTile } from "@/components/projects/ProjectTile";
import { SectionHead } from "@/components/ui/Primitives";
import { Reveal } from "@/components/ui/Reveal";
import { SplitText } from "@/components/ui/SplitText";
import type { Athlete, Project, ProjectType } from "@/data/types";
import { cn } from "@/lib/utils";

const TYPES: ProjectType[] = ["Matchday", "Motion", "Anúncio de jogador", "Carrossel", "Campanha editorial", "Experimental"];

const PROCESS = [
  { n: "01", t: "Briefing", d: "Entendemos o momento do atleta, o objetivo da peça e onde ela vai viver." },
  { n: "02", t: "Referências", d: "Moodboard, análise de perfil e definição de linguagem visual." },
  { n: "03", t: "Direção de arte", d: "Grid, tipografia, tratamento de imagem e primeiras composições." },
  { n: "04", t: "Produção", d: "Design, motion e versões para cada formato e plataforma." },
  { n: "05", t: "Entrega", d: "Arquivos finais, calendário de publicação e acompanhamento." },
];

export function CreativeLab({ projects, athletes }: { projects: Project[]; athletes: Athlete[] }) {
  const [type, setType] = useState<ProjectType | "Todos">("Todos");
  const [idx, setIdx] = useState<number | null>(null);
  const list = type === "Todos" ? projects : projects.filter((p) => p.type === type);

  return (
    <section id="creative-lab" className="relative border-t hairline bg-bone py-24 md:py-36">
      <div className="mx-auto max-w-[1600px] px-5 md:px-10">
        <SectionHead index="03" name="Creative Lab" coord="N 41°54′ · E 12°29′" />
        <div className="mt-10 grid gap-8 md:mt-14 md:grid-cols-12">
          <SplitText className="display text-[length:var(--text-giant)] md:col-span-8" lines={["Creative", "Lab"]} />
          <Reveal className="md:col-span-4 md:self-end">
            <p className="text-lg leading-snug text-graphite">Matchday, motion, anúncios, carrosséis e campanhas editoriais. O trabalho em primeiro plano — clique para abrir cada projeto.</p>
          </Reveal>
        </div>

        <div className="mt-14 flex gap-2 overflow-x-auto pb-2 [scrollbar-width:none]" role="tablist" aria-label="Categorias de projeto">
          {(["Todos", ...TYPES] as const).map((t) => {
            const count = t === "Todos" ? projects.length : projects.filter((p) => p.type === t).length;
            return (
              <button
                key={t}
                role="tab"
                aria-selected={type === t}
                onClick={() => setType(t)}
                className={cn("label relative shrink-0 rounded-full border px-4 py-2 transition-colors", type === t ? "border-ink text-white" : "border-ink/20 hover:border-ink")}
              >
                {type === t && <motion.span layoutId="lab-tab" className="absolute inset-0 rounded-full bg-ink" transition={{ type: "spring", stiffness: 380, damping: 32 }} />}
                <span className="relative">{t} <span className={type === t ? "text-white/50" : "text-ash"}>{count}</span></span>
              </button>
            );
          })}
        </div>

        <div className="mt-10 columns-1 gap-6 sm:columns-2 md:gap-8 lg:columns-3">
          <AnimatePresence mode="popLayout">
            {list.map((p, i) => (
              <ProjectTile key={p.slug} project={p} index={i} onOpen={() => setIdx(i)} />
            ))}
          </AnimatePresence>
        </div>

        <BehindTheCreation />
      </div>
      <ProjectModal list={list} index={idx} onClose={() => setIdx(null)} onIndex={setIdx} athletes={athletes} />
    </section>
  );
}

function BehindTheCreation() {
  const ref = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({ target: ref, offset: ["start 80%", "end 50%"] });
  const w = useTransform(scrollYProgress, [0, 1], ["0%", "100%"]);
  return (
    <div ref={ref} className="mt-28 border-t border-ink pt-10 md:mt-36">
      <div className="flex flex-col justify-between gap-6 md:flex-row md:items-end">
        <div>
          <p className="label text-ash">Exclusive · Behind the creation</p>
          <h3 className="display mt-4 text-[length:var(--text-display)]">Do briefing<br />ao matchday.</h3>
        </div>
        <p className="max-w-sm text-graphite">Um processo em cinco etapas, o mesmo para uma peça única ou uma temporada inteira.</p>
      </div>
      <div className="relative mt-14">
        <div className="absolute left-0 right-0 top-[7px] h-px bg-line" />
        <motion.div className="absolute left-0 top-[7px] h-px bg-ink" style={{ width: w }} />
        <div role="list" className="relative grid gap-10 md:grid-cols-5 md:gap-6">
          {PROCESS.map((s, i) => (
            <Reveal key={s.n} delay={i * 0.08}>
              <div role="listitem">
                <span className="block h-[15px] w-[15px] rounded-full border border-ink bg-bone" />
                <span className="label mt-6 block text-ash">{s.n}</span>
                <span className="mt-2 block text-xl font-semibold uppercase">{s.t}</span>
                <span className="mt-2 block text-sm leading-relaxed text-graphite">{s.d}</span>
              </div>
            </Reveal>
          ))}
        </div>
      </div>
    </div>
  );
}
