"use client";
import { AnimatePresence, motion } from "framer-motion";
import { AlertTriangle, ArrowUpRight, Check, Loader2 } from "lucide-react";
import { useState } from "react";
import { PillButton, SectionHead } from "@/components/ui/Primitives";
import { SplitText } from "@/components/ui/SplitText";
import { site } from "@/lib/site";
import { cn } from "@/lib/utils";

const CATEGORIES = ["Atleta profissional", "Jogador de futebol (base)", "Clube", "Agente de futebol", "Parceiro estratégico", "Outro"];
const AUDIENCE = ["Atletas profissionais", "Jogadores de futebol", "Clubes", "Agentes", "Parceiros estratégicos"];

type Fields = { name: string; email: string; country: string; category: string; message: string; consent: boolean; company: string };
const EMPTY: Fields = { name: "", email: "", country: "", category: "", message: "", consent: false, company: "" };

function validate(f: Fields) {
  const e: Partial<Record<keyof Fields, string>> = {};
  if (f.name.trim().length < 2) e.name = "Informe seu nome.";
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(f.email.trim())) e.email = "Informe um e-mail válido.";
  if (f.country.trim().length < 2) e.country = "Informe o país.";
  if (!f.category) e.category = "Selecione uma categoria.";
  if (f.message.trim().length < 20) e.message = "Conte um pouco mais (mínimo de 20 caracteres).";
  if (!f.consent) e.consent = "É preciso autorizar o contato.";
  return e;
}

type Status = { kind: "idle" } | { kind: "sending" } | { kind: "sent" } | { kind: "error"; msg: string } | { kind: "unconfigured" };

export function Contact() {
  const [f, setF] = useState<Fields>(EMPTY);
  const [touched, setTouched] = useState<Partial<Record<keyof Fields, boolean>>>({});
  const [status, setStatus] = useState<Status>({ kind: "idle" });
  const errors = validate(f);
  const show = (k: keyof Fields) => touched[k] && errors[k];
  const set = <K extends keyof Fields>(k: K, v: Fields[K]) => setF((s) => ({ ...s, [k]: v }));

  const mailto = site.email
    ? `mailto:${site.email}?subject=${encodeURIComponent(`DOMINUS — ${f.category || "Contato"} — ${f.name}`)}&body=${encodeURIComponent(`${f.message}\n\n${f.name}\n${f.email}\n${f.country} · ${f.category}`)}`
    : "";

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setTouched({ name: true, email: true, country: true, category: true, message: true, consent: true });
    if (Object.keys(errors).length) {
      const first = Object.keys(errors)[0];
      document.getElementById(`f-${first}`)?.focus();
      return;
    }
    if (f.company) return; // honeypot: silently ignore bots
    if (!site.formEndpoint) { setStatus({ kind: "unconfigured" }); return; }
    setStatus({ kind: "sending" });
    try {
      const res = await fetch(site.formEndpoint, {
        method: "POST",
        headers: { "Content-Type": "application/json", Accept: "application/json" },
        body: JSON.stringify({ name: f.name, email: f.email, country: f.country, category: f.category, message: f.message, source: "dominus-site" }),
      });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      setStatus({ kind: "sent" });
      setF(EMPTY); setTouched({});
    } catch {
      setStatus({ kind: "error", msg: "Não foi possível enviar agora. Tente novamente em instantes." });
    }
  }

  const field = "w-full border-b bg-transparent py-3 text-lg outline-none transition-colors placeholder:text-ash/70";
  const border = (k: keyof Fields) => (show(k) ? "border-ink border-dashed" : "border-ink/25 focus:border-ink");

  return (
    <section id="contact" className="relative overflow-hidden border-t hairline py-24 md:py-36">
      <div className="pointer-events-none absolute inset-0 bg-grid [mask-image:linear-gradient(to_bottom,transparent,black_30%,black_70%,transparent)]" />
      <div className="relative mx-auto max-w-[1600px] px-5 md:px-10">
        <SectionHead index="08" name="Be Part of It" coord="N 40°42′ · W 74°00′" />

        <SplitText className="display mt-12 text-[clamp(2.4rem,8.6vw,10rem)]" lines={["Your next", <span key="c" className="text-outline">chapter</span>, "starts here."]} />

        <div className="mt-16 grid gap-14 md:mt-24 md:grid-cols-12">
          <div className="md:col-span-4">
            <p className="text-lg leading-snug text-graphite">Atletas, clubes, agentes e parceiros: conte quem você é e o que quer construir. Respondemos pessoalmente.</p>
            <ul className="mt-8 space-y-2">
              {AUDIENCE.map((a, i) => (
                <li key={a} className="flex items-center gap-3 border-b hairline py-2"><span className="label tabular-nums text-ash">{String(i + 1).padStart(2, "0")}</span><span className="text-sm font-medium uppercase tracking-[0.08em]">{a}</span></li>
              ))}
            </ul>
            <div className="mt-10 space-y-6">
              <div>
                <p className="label text-ash">E-mail oficial</p>
                {site.email ? <a href={`mailto:${site.email}`} className="mt-1 block text-xl font-semibold hover:underline">{site.email}</a> : <p className="mt-1 text-xl font-semibold text-ash">A definir</p>}
              </div>
              <div>
                <p className="label text-ash">Redes sociais</p>
                <ul className="mt-2 flex flex-wrap gap-x-5 gap-y-2">
                  {site.socials.map((s) => s.href
                    ? <li key={s.label}><a href={s.href} target="_blank" rel="noreferrer" className="inline-flex items-center gap-1 text-sm font-medium uppercase tracking-[0.1em] hover:underline">{s.label}<ArrowUpRight className="h-3 w-3" /></a></li>
                    : <li key={s.label} className="text-sm font-medium uppercase tracking-[0.1em] text-ash" title="Link a definir">{s.label}</li>)}
                </ul>
              </div>
            </div>
          </div>

          <form onSubmit={submit} noValidate className="relative md:col-span-8" aria-describedby="form-status">
            <div className="relative border border-ink bg-paper p-6 md:p-10">
              <div className="mb-8 flex items-center justify-between">
                <span className="label">Collaboration form</span>
                <span className="label text-ash">Campos obrigatórios *</span>
              </div>
              <div className="grid gap-x-8 gap-y-8 md:grid-cols-2">
                <Field id="name" label="Nome *" error={show("name")}>
                  <input id="f-name" autoComplete="name" value={f.name} onChange={(e) => set("name", e.target.value)} onBlur={() => setTouched((t) => ({ ...t, name: true }))}
                    aria-invalid={!!show("name")} aria-describedby={show("name") ? "e-name" : undefined} className={cn(field, border("name"))} placeholder="Seu nome completo" />
                </Field>
                <Field id="email" label="E-mail *" error={show("email")}>
                  <input id="f-email" type="email" autoComplete="email" value={f.email} onChange={(e) => set("email", e.target.value)} onBlur={() => setTouched((t) => ({ ...t, email: true }))}
                    aria-invalid={!!show("email")} aria-describedby={show("email") ? "e-email" : undefined} className={cn(field, border("email"))} placeholder="voce@email.com" />
                </Field>
                <Field id="country" label="País *" error={show("country")}>
                  <input id="f-country" autoComplete="country-name" value={f.country} onChange={(e) => set("country", e.target.value)} onBlur={() => setTouched((t) => ({ ...t, country: true }))}
                    aria-invalid={!!show("country")} aria-describedby={show("country") ? "e-country" : undefined} className={cn(field, border("country"))} placeholder="Brasil, Portugal…" />
                </Field>
                <Field id="category" label="Categoria profissional *" error={show("category")}>
                  <select id="f-category" value={f.category} onChange={(e) => set("category", e.target.value)} onBlur={() => setTouched((t) => ({ ...t, category: true }))}
                    aria-invalid={!!show("category")} aria-describedby={show("category") ? "e-category" : undefined} className={cn(field, border("category"), "appearance-none rounded-none", !f.category && "text-ash/70")}>
                    <option value="">Selecione…</option>
                    {CATEGORIES.map((c) => <option key={c} value={c} className="text-ink">{c}</option>)}
                  </select>
                </Field>
                <div className="md:col-span-2">
                  <Field id="message" label="Mensagem *" error={show("message")}>
                    <textarea id="f-message" rows={5} value={f.message} onChange={(e) => set("message", e.target.value)} onBlur={() => setTouched((t) => ({ ...t, message: true }))}
                      aria-invalid={!!show("message")} aria-describedby={show("message") ? "e-message" : undefined} className={cn(field, border("message"), "resize-none")} placeholder="Conte sobre você, seu momento e o que quer construir." />
                  </Field>
                  <div className="mt-1 text-right font-mono text-[10px] text-ash">{f.message.trim().length} / 20+</div>
                </div>
              </div>

              {/* honeypot */}
              <input tabIndex={-1} autoComplete="off" value={f.company} onChange={(e) => set("company", e.target.value)} className="absolute left-[-9999px]" aria-hidden name="company" />

              <label className="mt-8 flex cursor-pointer items-start gap-3">
                <input id="f-consent" type="checkbox" checked={f.consent} onChange={(e) => { set("consent", e.target.checked); setTouched((t) => ({ ...t, consent: true })); }} className="peer sr-only" />
                <span className={cn("mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center border border-ink transition-colors peer-focus-visible:outline peer-focus-visible:outline-1 peer-focus-visible:outline-offset-2", f.consent && "bg-ink text-white")}>{f.consent && <Check className="h-3.5 w-3.5" />}</span>
                <span className="text-sm text-graphite">Autorizo a DOMINUS® a usar estes dados apenas para responder a este contato.</span>
              </label>
              {show("consent") && <p className="label mt-2 text-ink">{errors.consent}</p>}

              <div className="mt-10 flex flex-col gap-5 md:flex-row md:items-center md:justify-between">
                <PillButton type="submit" disabled={status.kind === "sending"}>
                  {status.kind === "sending" ? <><Loader2 className="h-4 w-4 animate-spin" /> Enviando</> : <>Enviar mensagem <ArrowUpRight className="h-4 w-4" /></>}
                </PillButton>
                <div id="form-status" aria-live="polite" className="md:max-w-sm">
                  <AnimatePresence mode="wait">
                    {status.kind === "sent" && (
                      <motion.p key="ok" initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }} className="flex items-center gap-2 text-sm font-medium"><Check className="h-4 w-4" /> Mensagem enviada. Retornaremos em breve.</motion.p>
                    )}
                    {status.kind === "error" && (
                      <motion.p key="err" initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }} className="flex items-center gap-2 text-sm"><AlertTriangle className="h-4 w-4" /> {status.msg}</motion.p>
                    )}
                    {status.kind === "unconfigured" && (
                      <motion.div key="cfg" initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }} className="border border-dashed border-ink/40 p-3 text-sm text-graphite">
                        <p className="flex items-center gap-2 font-medium text-ink"><AlertTriangle className="h-4 w-4" /> Envio online ainda não configurado.</p>
                        <p className="mt-1">Sua mensagem não foi enviada.{" "}
                          {mailto ? <a href={mailto} className="font-medium text-ink underline">Enviar por e-mail</a> : "Defina o endpoint do formulário e o e-mail oficial para ativar."}
                        </p>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>
              </div>
            </div>
          </form>
        </div>
      </div>
    </section>
  );
}

function Field({ id, label, error, children }: { id: string; label: string; error?: string | false; children: React.ReactNode }) {
  return (
    <div>
      <label htmlFor={`f-${id}`} className="label text-graphite">{label}</label>
      {children}
      {error && <p id={`e-${id}`} className="label mt-2 text-ink">— {error}</p>}
    </div>
  );
}
