"use client";
import { AnimatePresence, motion } from "framer-motion";
import { ArrowUpRight } from "lucide-react";
import Link from "next/link";
import { useState } from "react";
import { Counter } from "@/components/ui/Counter";
import { DemoBadge } from "@/components/ui/Primitives";
import { Radar } from "@/components/visuals/Radar";
import type { Athlete } from "@/data/types";
import { cn } from "@/lib/utils";

/** Exclusive feature: athlete statistics and visual analysis. Dark panel. */
export function PerformanceRoom({ athletes, embedded = false }: { athletes: Athlete[]; embedded?: boolean }) {
  const [i, setI] = useState(0);
  const a = athletes[i];
  if (!a) return null;
  const avg = a.stats.attributes.map((x, k) => ({
    label: x.label,
    value: Math.round(athletes.reduce((s, b) => s + b.stats.attributes[k].value, 0) / athletes.length),
  }));

  return (
    <section id={embedded ? undefined : "performance"} className={cn("relative overflow-hidden bg-ink text-white", !embedded && "py-24 md:py-32")}>
      <div className="absolute inset-0 bg-grid-dark" />
      <div className={cn("relative mx-auto max-w-[1600px]", !embedded && "px-5 md:px-10")}>
        {!embedded && (
          <div className="flex flex-col justify-between gap-6 border-b border-white/15 pb-8 md:flex-row md:items-end">
            <div>
              <p className="label text-white/50">Exclusive · Performance Room</p>
              <h2 className="display mt-4 text-[length:var(--text-display)]">Performance<br /><span className="text-outline-light">Room.</span></h2>
            </div>
            <p className="max-w-sm text-white/60">Estatísticas, atributos e análise visual. Cada atleta comparado com a média do elenco DOMINUS®.</p>
          </div>
        )}

        {!embedded && (
          <div className="mt-8 flex gap-2 overflow-x-auto pb-2 [scrollbar-width:none]" role="tablist" aria-label="Escolher atleta">
            {athletes.map((b, k) => (
              <button key={b.slug} role="tab" aria-selected={k === i} onClick={() => setI(k)}
                className={cn("label shrink-0 rounded-full border px-3.5 py-2 transition-colors", k === i ? "border-white bg-white text-ink" : "border-white/25 text-white/70 hover:border-white")}>
                {b.shortName}
              </button>
            ))}
          </div>
        )}

        <AnimatePresence mode="wait">
          <motion.div key={a.slug} initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -16 }} transition={{ duration: 0.45 }}
            className="mt-10 grid gap-10 md:grid-cols-12">
            <div className="md:col-span-5">
              <div className="relative mx-auto max-w-[460px]">
                <Radar data={a.stats.attributes} compare={avg} dark size={340} />
              </div>
              <div className="mt-4 flex items-center justify-center gap-6">
                <span className="label flex items-center gap-2 text-white/70"><span className="h-px w-5 bg-white" /> {a.shortName}</span>
                <span className="label flex items-center gap-2 text-white/50"><span className="h-px w-5 border-t border-dashed border-white/60" /> Média do elenco</span>
              </div>
            </div>
            <div className="md:col-span-7">
              <div className="flex items-start justify-between gap-4">
                <div>
                  <p className="label text-white/50">#{a.number} · {a.position} · {a.club}</p>
                  <h3 className="mt-2 text-4xl font-semibold uppercase tracking-[-0.03em] md:text-5xl">{a.name}</h3>
                </div>
                {a.demo && <DemoBadge dark />}
              </div>
              <div className="mt-8 grid grid-cols-2 gap-px bg-white/15 md:grid-cols-4">
                {a.stats.season.map((s) => (
                  <div key={s.label} className="bg-ink p-4">
                    <Counter value={s.value} suffix={s.suffix} className="block text-4xl font-semibold tabular-nums tracking-[-0.03em]" />
                    <span className="label mt-2 block text-white/50">{s.label}</span>
                  </div>
                ))}
              </div>
              <ul className="mt-8 space-y-3">
                {a.stats.attributes.map((s, k) => (
                  <li key={s.label} className="grid grid-cols-[120px_1fr_40px] items-center gap-4">
                    <span className="label text-white/60">{s.label}</span>
                    <span className="relative h-[3px] bg-white/10">
                      <motion.span className="absolute inset-y-0 left-0 bg-white" initial={{ width: 0 }} animate={{ width: `${s.value}%` }} transition={{ duration: 1, delay: k * 0.06, ease: [0.16, 1, 0.3, 1] }} />
                      <span className="absolute -top-1 h-[11px] w-px bg-white/50" style={{ left: `${avg[k].value}%` }} />
                    </span>
                    <span className="text-right font-mono text-sm tabular-nums">{s.value}</span>
                  </li>
                ))}
              </ul>
              {!embedded && (
                <Link href={`/atletas/${a.slug}/`} data-cursor="hover" className="mt-10 inline-flex items-center gap-3 border-b border-white/50 pb-1 text-sm font-semibold uppercase tracking-[0.12em] hover:border-white">
                  Perfil completo <ArrowUpRight className="h-4 w-4" />
                </Link>
              )}
            </div>
          </motion.div>
        </AnimatePresence>
      </div>
    </section>
  );
}
