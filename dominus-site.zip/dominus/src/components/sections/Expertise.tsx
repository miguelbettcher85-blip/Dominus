"use client";
import { AnimatePresence, motion, useMotionValue, useSpring } from "framer-motion";
import { Plus } from "lucide-react";
import { useState } from "react";
import { SectionHead } from "@/components/ui/Primitives";
import { Reveal } from "@/components/ui/Reveal";
import { SplitText } from "@/components/ui/SplitText";
import { Artwork } from "@/components/visuals/Artwork";
import type { Project } from "@/data/types";
import { cn } from "@/lib/utils";

// Visual previews are illustrative compositions, not portfolio claims.
const pv = (slug: string, title: string, type: Project["type"], ratio: Project["ratio"] = "portrait"): Project => ({
  slug, title, type, ratio, campaign: "Preview", year: 2026, summary: "", behindTheScenes: "",
});

const SERVICES = [
  { t: "Athlete Branding", d: "Identidade visual completa do atleta: monograma, paleta, tipografia, tratamento de imagem e guia de uso.", tags: ["Identidade", "Guia de marca", "Fotografia"], p: pv("sv-1", "Grid System", "Experimental", "square") },
  { t: "Matchday Design", d: "Sistema de peças para dias de jogo — pré-jogo, escalação, intervalo, resultado e celebração — prontas para publicar em segundos.", tags: ["Pré-jogo", "Resultado", "Telão"], p: pv("sv-2", "DOM × OPP", "Matchday") },
  { t: "Motion Design", d: "Animações para redes e telões: intros, highlights, reels de perfil e anúncios em movimento.", tags: ["Reels", "Intros", "Highlights"], p: pv("sv-3", "Motion", "Motion", "landscape") },
  { t: "Player Carousel", d: "Carrosséis editoriais que contam a temporada, os números e a história do atleta slide a slide.", tags: ["Instagram", "LinkedIn", "Infográficos"], p: pv("sv-4", "Temporada", "Carrossel", "square") },
  { t: "Profile Analysis", d: "Diagnóstico do perfil digital: posicionamento atual, público, concorrência e oportunidades.", tags: ["Diagnóstico", "Benchmark", "Relatório"], p: pv("sv-5", "Análise", "Campanha editorial") },
  { t: "Strategic Content Planning", d: "Calendário editorial alinhado à temporada, com formatos, frequência e rotinas de produção.", tags: ["Calendário", "Formatos", "Rotina"], p: pv("sv-6", "Plano", "Experimental", "square") },
  { t: "Club & Agent Presentations", d: "Apresentações profissionais do atleta para clubes, agentes e parceiros — claras, visuais e prontas para negociação.", tags: ["Deck", "Scouting visual", "PDF"], p: pv("sv-7", "Welcome, Atleta", "Anúncio de jogador", "landscape") },
];

export function Expertise() {
  const [hover, setHover] = useState<number | null>(null);
  const [open, setOpen] = useState<number | null>(0);
  const x = useMotionValue(0), y = useMotionValue(0);
  const sx = useSpring(x, { stiffness: 200, damping: 25 }), sy = useSpring(y, { stiffness: 200, damping: 25 });

  return (
    <section id="expertise" className="relative border-t hairline bg-paper py-24 md:py-36"
      onPointerMove={(e) => { x.set(e.clientX); y.set(e.clientY); }}>
      <div className="mx-auto max-w-[1600px] px-5 md:px-10">
        <SectionHead index="06" name="Our Expertise" coord="N 25°12′ · E 55°16′" />
        <div className="mt-10 grid gap-8 md:mt-14 md:grid-cols-12">
          <SplitText className="display text-[length:var(--text-giant)] md:col-span-8" lines={["Our", "Expertise"]} />
          <Reveal className="md:col-span-4 md:self-end">
            <p className="text-lg leading-snug text-graphite">Sete serviços criativos que trabalham juntos — do primeiro diagnóstico à peça publicada no dia do jogo.</p>
          </Reveal>
        </div>

        <ul className="mt-16 border-t border-ink" onMouseLeave={() => setHover(null)}>
          {SERVICES.map((s, i) => {
            const isOpen = open === i;
            return (
              <li key={s.t} className="border-b border-ink" onMouseEnter={() => setHover(i)}>
                <button onClick={() => setOpen(isOpen ? null : i)} aria-expanded={isOpen} data-cursor-label={isOpen ? "Fechar" : "Abrir"}
                  className="group grid w-full grid-cols-[40px_1fr_auto] items-center gap-4 py-6 text-left md:grid-cols-[80px_1fr_auto] md:py-8">
                  <span className="label tabular-nums text-ash">{String(i + 1).padStart(2, "0")}</span>
                  <span className={cn("wide text-[clamp(1.4rem,3.8vw,3.8rem)] font-semibold uppercase leading-none tracking-[-0.04em] transition-[transform,color] duration-700 ease-out-expo md:group-hover:translate-x-4",
                    hover !== null && hover !== i && "text-ink/25")}>
                    {s.t}
                  </span>
                  <span className={cn("flex h-10 w-10 items-center justify-center rounded-full border border-ink transition-all duration-500", isOpen && "rotate-45 bg-ink text-white")}>
                    <Plus className="h-4 w-4" />
                  </span>
                </button>
                <AnimatePresence initial={false}>
                  {isOpen && (
                    <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: "auto", opacity: 1 }} exit={{ height: 0, opacity: 0 }} transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }} className="overflow-hidden">
                      <div className="grid gap-6 pb-8 md:grid-cols-[80px_1fr_1fr] md:gap-4">
                        <span />
                        <p className="max-w-lg text-lg leading-relaxed text-graphite">{s.d}</p>
                        <div className="flex flex-wrap content-start gap-2">
                          {s.tags.map((t) => <span key={t} className="label rounded-full border border-ink/20 px-3 py-1.5">{t}</span>)}
                        </div>
                        <div className="w-40 md:hidden"><Artwork project={s.p} /></div>
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </li>
            );
          })}
        </ul>
      </div>

      {/* floating preview that follows the pointer (desktop) */}
      <motion.div aria-hidden className="pointer-events-none fixed left-0 top-0 z-30 hidden w-[260px] md:block" style={{ x: sx, y: sy, translateX: "40px", translateY: "-50%" }}>
        <AnimatePresence>
          {hover !== null && (
            <motion.div key={hover} initial={{ opacity: 0, scale: 0.85, rotate: -4 }} animate={{ opacity: 1, scale: 1, rotate: 0 }} exit={{ opacity: 0, scale: 0.9 }} transition={{ duration: 0.4, ease: [0.16, 1, 0.3, 1] }}
              className="absolute inset-x-0 top-0 -translate-y-1/2 shadow-[0_30px_60px_-30px_rgba(0,0,0,0.45)]">
              <Artwork project={SERVICES[hover].p} />
            </motion.div>
          )}
        </AnimatePresence>
      </motion.div>
    </section>
  );
}
