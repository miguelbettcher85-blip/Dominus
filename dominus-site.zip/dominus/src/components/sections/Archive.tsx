"use client";
import { AnimatePresence, motion } from "framer-motion";
import { LayoutGrid, List, Play, Search } from "lucide-react";
import { useMemo, useState } from "react";
import { ProjectModal } from "@/components/projects/ProjectModal";
import { SectionHead } from "@/components/ui/Primitives";
import { Reveal } from "@/components/ui/Reveal";
import { SplitText } from "@/components/ui/SplitText";
import { Artwork } from "@/components/visuals/Artwork";
import type { Athlete, Project } from "@/data/types";
import { cn } from "@/lib/utils";

export function Archive({ projects, athletes }: { projects: Project[]; athletes: Athlete[] }) {
  const [athlete, setAthlete] = useState("");
  const [campaign, setCampaign] = useState("");
  const [type, setType] = useState("");
  const [year, setYear] = useState("");
  const [q, setQ] = useState("");
  const [view, setView] = useState<"grid" | "list">("list");
  const [idx, setIdx] = useState<number | null>(null);
  const [hover, setHover] = useState<string | null>(null);

  const sorted = useMemo(() => [...projects].sort((a, b) => b.year - a.year || a.title.localeCompare(b.title)), [projects]);
  const name = (slug?: string) => athletes.find((a) => a.slug === slug)?.name ?? "—";
  const opts = {
    athlete: Array.from(new Set(projects.map((p) => p.athleteSlug).filter(Boolean))) as string[],
    campaign: Array.from(new Set(projects.map((p) => p.campaign))).sort(),
    type: Array.from(new Set(projects.map((p) => p.type))).sort(),
    year: Array.from(new Set(projects.map((p) => String(p.year)))).sort().reverse(),
  };
  const list = sorted.filter((p) =>
    (!athlete || p.athleteSlug === athlete) && (!campaign || p.campaign === campaign) && (!type || p.type === type) && (!year || String(p.year) === year) &&
    (!q || `${p.title} ${p.campaign} ${p.type} ${name(p.athleteSlug)}`.toLowerCase().includes(q.toLowerCase())),
  );

  const Select = ({ label, value, set, options, fmt }: { label: string; value: string; set: (v: string) => void; options: string[]; fmt?: (v: string) => string }) => (
    <label className="relative block">
      <span className="sr-only">{label}</span>
      <select value={value} onChange={(e) => set(e.target.value)}
        className={cn("label w-full appearance-none rounded-none border-b bg-transparent py-3 pr-6 outline-none transition-colors", value ? "border-ink" : "border-ink/20 hover:border-ink")}>
        <option value="">{label} — todos</option>
        {options.map((o) => <option key={o} value={o}>{fmt ? fmt(o) : o}</option>)}
      </select>
      <span className="pointer-events-none absolute right-0 top-1/2 -translate-y-1/2 text-xs">▾</span>
    </label>
  );

  return (
    <section id="archive" className="relative border-t hairline bg-bone py-24 md:py-36">
      <div className="mx-auto max-w-[1600px] px-5 md:px-10">
        <SectionHead index="07" name="The DOMINUS Archive" coord="N 35°41′ · E 139°41′" />
        <div className="mt-10 grid gap-8 md:mt-14 md:grid-cols-12">
          <SplitText className="display text-[length:var(--text-giant)] md:col-span-8" lines={["The", "Archive"]} />
          <Reveal className="md:col-span-4 md:self-end">
            <p className="text-lg leading-snug text-graphite">Todo o trabalho em um só lugar: projetos recentes, campanhas, vídeos e materiais históricos — por atleta, campanha, tipo e ano.</p>
          </Reveal>
        </div>

        <div className="mt-14 grid gap-4 md:grid-cols-12 md:items-end">
          <label className="relative md:col-span-3">
            <span className="sr-only">Buscar no arquivo</span>
            <Search className="pointer-events-none absolute left-0 top-1/2 h-4 w-4 -translate-y-1/2" />
            <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Buscar…" className="label w-full border-b border-ink bg-transparent py-3 pl-7 outline-none placeholder:text-ash" />
          </label>
          <div className="md:col-span-2"><Select label="Atleta" value={athlete} set={setAthlete} options={opts.athlete} fmt={name} /></div>
          <div className="md:col-span-2"><Select label="Campanha" value={campaign} set={setCampaign} options={opts.campaign} /></div>
          <div className="md:col-span-2"><Select label="Tipo" value={type} set={setType} options={opts.type} /></div>
          <div className="md:col-span-2"><Select label="Ano" value={year} set={setYear} options={opts.year} /></div>
          <div className="flex items-center justify-between gap-3 md:col-span-1 md:justify-end">
            <span className="label tabular-nums text-ash md:hidden" aria-live="polite">{String(list.length).padStart(2, "0")} itens</span>
            <div className="flex border border-ink">
              <button aria-label="Ver em lista" aria-pressed={view === "list"} onClick={() => setView("list")} className={cn("p-2", view === "list" && "bg-ink text-white")}><List className="h-4 w-4" /></button>
              <button aria-label="Ver em grade" aria-pressed={view === "grid"} onClick={() => setView("grid")} className={cn("p-2", view === "grid" && "bg-ink text-white")}><LayoutGrid className="h-4 w-4" /></button>
            </div>
          </div>
        </div>

        {view === "list" ? (
          <div className="relative mt-10 grid gap-8 md:grid-cols-12">
            <ul className="border-t border-ink md:col-span-8" onMouseLeave={() => setHover(null)}>
              <li className="hidden grid-cols-[70px_1.4fr_1fr_1fr_40px] gap-4 border-b hairline py-3 md:grid">
                {["Ano", "Projeto", "Atleta", "Tipo", ""].map((h) => <span key={h} className="label text-ash">{h}</span>)}
              </li>
              <AnimatePresence initial={false}>
                {list.map((p, i) => (
                  <motion.li key={p.slug} layout initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
                    <button onClick={() => setIdx(i)} onMouseEnter={() => setHover(p.slug)} onFocus={() => setHover(p.slug)} data-cursor-label="Abrir"
                      className="group grid w-full grid-cols-[50px_1fr_auto] items-center gap-4 border-b hairline py-4 text-left transition-colors hover:bg-paper md:grid-cols-[70px_1.4fr_1fr_1fr_40px]">
                      <span className="label tabular-nums">{p.year}</span>
                      <span className="font-semibold uppercase tracking-[-0.01em] transition-transform duration-500 group-hover:translate-x-2">{p.title}</span>
                      <span className="hidden text-sm text-graphite md:block">{name(p.athleteSlug)}</span>
                      <span className="label hidden text-graphite md:block">{p.type}</span>
                      <span className="flex justify-end">{p.type === "Motion" ? <Play className="h-4 w-4" /> : <span className="h-1.5 w-1.5 bg-ink" />}</span>
                    </button>
                  </motion.li>
                ))}
              </AnimatePresence>
            </ul>
            <div className="hidden md:col-span-4 md:block">
              <div className="sticky top-28 aspect-square overflow-hidden border border-ink bg-paper">
                <AnimatePresence mode="wait">
                  {(() => {
                    const p = projects.find((x) => x.slug === (hover ?? list[0]?.slug));
                    return p ? (
                      <motion.div key={p.slug} className="absolute inset-0" initial={{ opacity: 0, scale: 1.04 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0 }} transition={{ duration: 0.4 }}>
                        <Artwork project={{ ...p, ratio: "square" }} />
                        <span className="label absolute bottom-3 left-3 bg-paper px-2 py-1">{p.campaign}</span>
                      </motion.div>
                    ) : null;
                  })()}
                </AnimatePresence>
              </div>
            </div>
          </div>
        ) : (
          <motion.div layout className="mt-10 grid grid-cols-2 gap-4 md:grid-cols-4 md:gap-6">
            <AnimatePresence>
              {list.map((p, i) => (
                <motion.button key={p.slug} layout initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }} onClick={() => setIdx(i)} data-cursor-label="Abrir" className="group text-left">
                  <div className="relative aspect-square overflow-hidden">
                    <div className="h-full w-full transition-transform duration-700 group-hover:scale-105"><Artwork project={{ ...p, ratio: "square" }} /></div>
                    {p.type === "Motion" && <span className="absolute right-2 top-2 flex h-8 w-8 items-center justify-center rounded-full bg-paper"><Play className="h-3.5 w-3.5" /></span>}
                  </div>
                  <div className="mt-2 flex justify-between gap-2"><span className="truncate text-sm font-semibold uppercase">{p.title}</span><span className="label text-ash">{p.year}</span></div>
                </motion.button>
              ))}
            </AnimatePresence>
          </motion.div>
        )}
        {list.length === 0 && <p className="mt-6 text-graphite">Nenhum item encontrado.</p>}
      </div>
      <ProjectModal list={list} index={idx} onClose={() => setIdx(null)} onIndex={setIdx} athletes={athletes} />
    </section>
  );
}
