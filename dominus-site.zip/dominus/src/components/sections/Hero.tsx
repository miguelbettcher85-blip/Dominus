"use client";
import { motion, useScroll, useTransform } from "framer-motion";
import { ArrowDown, ArrowUpRight } from "lucide-react";
import { useRef, useState } from "react";
import { useReady, scrollToId } from "@/components/layout/Providers";
import { Brackets } from "@/components/ui/Primitives";
import { SplitText } from "@/components/ui/SplitText";
import { WireSphere } from "@/components/visuals/WireSphere";

const SERVICES = ["Athlete Branding", "Matchday Design", "Motion Design", "Player Carousel", "Profile Analysis", "Content Planning", "Club & Agent Presentations"];

// Optional hero photograph (path under /public). While empty, the wireframe ball leads.
const HERO_IMAGE = "";

export function Hero() {
  const ready = useReady();
  const ref = useRef<HTMLElement>(null);
  const panel = useRef<HTMLDivElement>(null);
  const [coord, setCoord] = useState({ x: 0, y: 0 });
  const { scrollYProgress } = useScroll({ target: ref, offset: ["start start", "end start"] });
  const panelY = useTransform(scrollYProgress, [0, 1], ["0%", "-6%"]);
  const textY = useTransform(scrollYProgress, [0, 1], ["0%", "-12%"]);

  const onMove = (e: React.PointerEvent) => {
    const r = panel.current?.getBoundingClientRect();
    if (!r) return;
    setCoord({ x: Math.round(e.clientX - r.left), y: Math.round(e.clientY - r.top) });
  };

  const fade = (d: number) => ({
    initial: { opacity: 0, y: 16 },
    animate: ready ? { opacity: 1, y: 0 } : {},
    transition: { duration: 0.9, delay: d, ease: [0.16, 1, 0.3, 1] as const },
  });

  return (
    <section id="home" ref={ref} className="relative min-h-[100svh] overflow-hidden pt-24 md:pt-28" onPointerMove={onMove}>
      <div className="pointer-events-none absolute inset-0 bg-grid [mask-image:linear-gradient(to_bottom,black_40%,transparent)]" />

      <div className="relative mx-auto flex max-w-[1600px] flex-col px-5 md:px-10">
        {/* top meta row */}
        <motion.div {...fade(0.1)} className="flex items-center justify-between border-b hairline pb-4">
          <span className="label">01 — Introduction</span>
          <span className="label hidden text-ash md:block">DOMINUS® / Marketing Desportivo</span>
          <span className="label text-ash">Index 01/08</span>
        </motion.div>

        <div className="relative mt-8 grid grid-cols-12 gap-x-5 md:mt-10">
          {/* Black panel (photo / wireframe ball) sits under the blended headline */}
          <motion.div
            ref={panel}
            style={{ y: panelY }}
            initial={{ clipPath: "inset(100% 0 0 0)" }}
            animate={ready ? { clipPath: "inset(0% 0 0 0)" } : {}}
            transition={{ duration: 1.4, delay: 0.15, ease: [0.76, 0, 0.24, 1] }}
            className="relative order-2 col-span-12 mt-8 aspect-[4/5] overflow-hidden bg-ink md:order-none md:col-span-5 md:col-start-8 md:row-start-1 md:mt-0 md:aspect-auto md:h-[min(72vh,760px)]"
          >
            <div className="absolute inset-0 bg-grid-dark" />
            {HERO_IMAGE ? (
              // eslint-disable-next-line @next/next/no-img-element
              <img src={HERO_IMAGE} alt="" className="absolute inset-0 h-full w-full object-cover grayscale" />
            ) : (
              <WireSphere className="absolute inset-0 h-full w-full" color="255,255,255" />
            )}
            <div className="scanline scanline-light" />
            <Brackets dark className="m-4" />
            <div className="absolute left-6 top-6 flex flex-col gap-1 text-white/60">
              <span className="label-sm">Obj. 001 — Match ball</span>
              <span className="label-sm tabular-nums">X {String(coord.x).padStart(4, "0")} · Y {String(coord.y).padStart(4, "0")}</span>
            </div>
            <div className="absolute right-6 top-6 text-right text-white/60">
              <span className="label-sm block">Scan</span>
              <span className="label-sm block">Active<span className="blink">_</span></span>
            </div>
            <div className="absolute inset-x-6 bottom-6 flex items-end justify-between text-white">
              <div>
                <span className="label-sm block text-white/50">Frame</span>
                <span className="text-sm font-medium tracking-wide">Beyond the field</span>
              </div>
              <span className="label-sm text-white/50">{HERO_IMAGE ? "Foto" : "Wireframe · 18×28"}</span>
            </div>
          </motion.div>

          {/* Headline — mix-blend-difference flips it to white over the panel */}
          <motion.div style={{ y: textY }} className="pointer-events-none relative z-10 order-1 col-span-12 text-white mix-blend-difference md:order-none md:col-start-1 md:row-start-1 md:self-center">
            <SplitText
              as="h1"
              play={ready}
              delay={0.35}
              className="display text-[clamp(2.8rem,12.2vw,13.5rem)]"
              lines={["Built to", "dominate."]}
            />
          </motion.div>
        </div>

        {/* lower band */}
        <div className="relative mt-10 grid grid-cols-12 gap-5 pb-10 md:mt-12">
          <motion.p {...fade(0.9)} className="col-span-12 max-w-md text-lg leading-snug text-graphite md:col-span-5 md:text-xl">
            We build identities, develop visibility and create opportunities for athletes beyond the field.
          </motion.p>
          <motion.div {...fade(1)} className="col-span-12 flex flex-wrap items-center gap-4 md:col-span-7 md:justify-end md:self-end">
            <a href="#athletes" onClick={(e) => { if (scrollToId("athletes")) e.preventDefault(); }} data-cursor="hover"
              className="group inline-flex items-center gap-3 rounded-full bg-ink px-6 py-3.5 text-[0.8rem] font-semibold uppercase tracking-[0.14em] text-white">
              Athlete Universe <ArrowUpRight className="h-4 w-4 transition-transform group-hover:rotate-45" />
            </a>
            <a href="#contact" onClick={(e) => { if (scrollToId("contact")) e.preventDefault(); }} data-cursor="hover"
              className="inline-flex items-center gap-3 rounded-full border border-ink px-6 py-3.5 text-[0.8rem] font-semibold uppercase tracking-[0.14em] transition-colors hover:bg-ink hover:text-white">
              Be part of it
            </a>
          </motion.div>
        </div>

        <motion.button
          {...fade(1.2)}
          onClick={() => scrollToId("athletes")}
          className="mx-auto mb-8 hidden flex-col items-center gap-3 md:flex"
          aria-label="Rolar para a próxima seção"
          data-cursor="hover"
        >
          <span className="label text-ash">Scroll</span>
          <span className="relative h-12 w-px overflow-hidden bg-line">
            <motion.span className="absolute left-0 top-0 h-1/2 w-px bg-ink" animate={{ y: ["-100%", "200%"] }} transition={{ duration: 1.8, repeat: Infinity, ease: [0.76, 0, 0.24, 1] }} />
          </span>
          <ArrowDown className="h-3.5 w-3.5" />
        </motion.button>
      </div>

      {/* service marquee */}
      <div className="relative overflow-hidden border-y hairline bg-paper py-5">
        <div className="marquee flex w-max gap-10 whitespace-nowrap">
          {[...SERVICES, ...SERVICES].map((s, i) => (
            <span key={i} className="flex items-center gap-10 wide text-3xl font-semibold uppercase tracking-[-0.03em] md:text-5xl">
              <span className={i % 2 ? "text-outline" : ""}>{s}</span>
              <span className="h-2 w-2 rotate-45 bg-ink" />
            </span>
          ))}
        </div>
      </div>
    </section>
  );
}
