import { ArrowUpRight } from "lucide-react";
import Link from "next/link";
import { cn } from "@/lib/utils";

/** Section opener: index + name on a hairline, with a coordinate readout. */
export function SectionHead({
  index,
  name,
  coord,
  className,
  dark = false,
}: {
  index: string;
  name: string;
  coord?: string;
  className?: string;
  dark?: boolean;
}) {
  return (
    <div className={cn("flex items-center gap-4 border-b pb-4", dark ? "border-white/15 text-white" : "hairline", className)}>
      <span className="label">{index}</span>
      <span className={cn("h-px w-8", dark ? "bg-white/40" : "bg-ink")} />
      <span className="label">{name}</span>
      <span className={cn("label ml-auto hidden sm:block", dark ? "text-white/45" : "text-ash")}>{coord}</span>
    </div>
  );
}

/** Corner brackets framing a technical panel. */
export function Brackets({ className, dark = false }: { className?: string; dark?: boolean }) {
  const c = dark ? "border-white/60" : "border-ink";
  const s = "absolute h-3 w-3";
  return (
    <span aria-hidden className={cn("pointer-events-none absolute inset-0", className)}>
      <span className={cn(s, c, "left-0 top-0 border-l border-t")} />
      <span className={cn(s, c, "right-0 top-0 border-r border-t")} />
      <span className={cn(s, c, "bottom-0 left-0 border-b border-l")} />
      <span className={cn(s, c, "bottom-0 right-0 border-b border-r")} />
    </span>
  );
}

export function DemoBadge({ className, dark = false }: { className?: string; dark?: boolean }) {
  return (
    <span
      title="Conteúdo de demonstração — substituir por dados reais"
      className={cn(
        "label-sm inline-flex items-center gap-1.5 rounded-full border px-2 py-0.5",
        dark ? "border-white/30 text-white/70" : "border-ink/25 text-graphite",
        className,
      )}
    >
      <span className={cn("h-1 w-1 rounded-full", dark ? "bg-white/70" : "bg-ink/60")} /> Demo
    </span>
  );
}

export function ArrowLink({
  href,
  children,
  className,
  dark = false,
}: {
  href: string;
  children: React.ReactNode;
  className?: string;
  dark?: boolean;
}) {
  return (
    <Link
      href={href}
      data-cursor="hover"
      className={cn(
        "group inline-flex items-center gap-3 border-b pb-1 text-sm font-medium uppercase tracking-[0.12em] transition-colors",
        dark ? "border-white/40 text-white hover:border-white" : "border-ink/30 hover:border-ink",
        className,
      )}
    >
      {children}
      <ArrowUpRight className="h-4 w-4 transition-transform duration-500 ease-out-expo group-hover:-translate-y-0.5 group-hover:translate-x-0.5" />
    </Link>
  );
}

/** Pill button used for primary actions. Inverts on hover. */
export function PillButton({
  children,
  className,
  dark = false,
  ...rest
}: React.ButtonHTMLAttributes<HTMLButtonElement> & { dark?: boolean }) {
  return (
    <button
      data-cursor="hover"
      className={cn(
        "group relative inline-flex items-center justify-center gap-3 overflow-hidden rounded-full border px-6 py-3.5 text-[0.8rem] font-semibold uppercase tracking-[0.14em] transition-colors duration-500 disabled:opacity-50",
        dark ? "border-white bg-white text-ink hover:text-white" : "border-ink bg-ink text-white hover:text-ink",
        className,
      )}
      {...rest}
    >
      <span
        className={cn(
          "absolute inset-0 translate-y-full rounded-full transition-transform duration-500 ease-out-expo group-hover:translate-y-0",
          dark ? "bg-ink" : "bg-white",
        )}
      />
      <span className="relative inline-flex items-center gap-3">{children}</span>
    </button>
  );
}
