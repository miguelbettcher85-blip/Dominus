"use client";
import { motion } from "framer-motion";
import { cn } from "@/lib/utils";

/**
 * Line-by-line masked reveal for display headlines.
 * Pass lines as an array so the break points are art-directed, not automatic.
 */
export function SplitText({
  lines,
  className,
  lineClassName,
  delay = 0,
  as: Tag = "h2",
  play,
}: {
  lines: (string | React.ReactNode)[];
  className?: string;
  lineClassName?: string;
  delay?: number;
  as?: "h1" | "h2" | "h3" | "p";
  /** When provided, the reveal is driven by this flag instead of viewport entry. */
  play?: boolean;
}) {
  const trigger = play !== undefined
    ? { animate: { y: play ? "0%" : "105%" } }
    : { whileInView: { y: "0%" }, viewport: { once: true, margin: "-8% 0px" } };
  return (
    <Tag className={className}>
      {lines.map((line, i) => (
        <span key={i} className="block overflow-hidden pb-[0.06em] -mb-[0.06em]">
          <motion.span
            className={cn("block will-change-transform", lineClassName)}
            initial={{ y: "105%" }}
            {...trigger}
            transition={{ duration: 1.1, delay: delay + i * 0.09, ease: [0.16, 1, 0.3, 1] }}
          >
            {line}
          </motion.span>
        </span>
      ))}
    </Tag>
  );
}
