"use client";
import { motion } from "framer-motion";
import type { Project } from "@/data/types";
import { Artwork, ratioClass } from "@/components/visuals/Artwork";

export function ProjectTile({ project, index, onOpen }: { project: Project; index: number; onOpen: () => void }) {
  return (
    <motion.button
      initial={{ opacity: 0, y: 40 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.7, ease: [0.16, 1, 0.3, 1] }}
      onClick={onOpen}
      data-cursor-label="Abrir"
      className="group mb-6 block w-full break-inside-avoid text-left md:mb-8"
      aria-label={`Abrir ${project.title}`}
    >
      <div className={`relative overflow-hidden bg-bone ${ratioClass[project.ratio]}`}>
        <div className="h-full w-full transition-transform duration-[1.2s] ease-out-expo group-hover:scale-[1.04]">
          <Artwork project={project} />
        </div>
        <div className="absolute inset-0 bg-ink/0 transition-colors duration-500 group-hover:bg-ink/10" />
        <span className="label-sm absolute left-3 top-3 bg-paper px-1.5 py-0.5 opacity-0 transition-opacity duration-500 group-hover:opacity-100">
          {project.type}
        </span>
      </div>
      <div className="mt-3 flex items-baseline gap-3">
        <span className="label tabular-nums text-ash">{String(index + 1).padStart(2, "0")}</span>
        <span className="font-semibold uppercase tracking-[-0.01em]">{project.title}</span>
        <span className="label ml-auto text-ash">{project.year}</span>
      </div>
      <span className="mt-2 block h-px w-full origin-left scale-x-0 bg-ink transition-transform duration-700 ease-out-expo group-hover:scale-x-100" />
    </motion.button>
  );
}
