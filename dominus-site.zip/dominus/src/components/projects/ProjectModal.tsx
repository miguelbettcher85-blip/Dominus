"use client";
import { AnimatePresence, motion } from "framer-motion";
import { ArrowLeft, ArrowRight, ArrowUpRight, X } from "lucide-react";
import Link from "next/link";
import { useEffect, useRef } from "react";
import { createPortal } from "react-dom";
import type { Athlete, Project } from "@/data/types";
import { Artwork } from "@/components/visuals/Artwork";
import { DemoBadge } from "@/components/ui/Primitives";

/** Fullscreen project preview shared by Creative Lab, Archive and athlete pages. */
export function ProjectModal({
  list,
  index,
  onClose,
  onIndex,
  athletes,
}: {
  list: Project[];
  index: number | null;
  onClose: () => void;
  onIndex: (i: number) => void;
  athletes: Athlete[];
}) {
  const closeRef = useRef<HTMLButtonElement>(null);
  const open = index !== null && !!list[index];
  const p = open ? list[index!] : null;
  const athlete = p?.athleteSlug ? athletes.find((a) => a.slug === p.athleteSlug) : undefined;

  useEffect(() => {
    if (!open) return;
    window.__lenis?.stop();
    document.documentElement.style.overflow = "hidden";
    const prevFocus = document.activeElement as HTMLElement | null;
    closeRef.current?.focus();
    const key = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
      if (e.key === "ArrowRight") onIndex((index! + 1) % list.length);
      if (e.key === "ArrowLeft") onIndex((index! - 1 + list.length) % list.length);
    };
    window.addEventListener("keydown", key);
    return () => {
      window.removeEventListener("keydown", key);
      window.__lenis?.start();
      document.documentElement.style.overflow = "";
      prevFocus?.focus?.();
    };
  }, [open, index, list.length, onClose, onIndex]);

  if (typeof document === "undefined") return null;
  return createPortal(
    <AnimatePresence>
      {p && (
        <motion.div
          key="modal"
          role="dialog"
          aria-modal="true"
          aria-label={p.title}
          className="fixed inset-0 z-[80] flex flex-col bg-paper"
          initial={{ clipPath: "inset(100% 0 0 0)" }}
          animate={{ clipPath: "inset(0% 0 0 0)" }}
          exit={{ clipPath: "inset(0 0 100% 0)" }}
          transition={{ duration: 0.8, ease: [0.76, 0, 0.24, 1] }}
          data-lenis-prevent
        >
          <div className="flex items-center justify-between border-b hairline px-5 py-4 md:px-10">
            <span className="label tabular-nums">
              {String(index! + 1).padStart(2, "0")} / {String(list.length).padStart(2, "0")} — {p.type}
            </span>
            <div className="flex items-center gap-2">
              <button onClick={() => onIndex((index! - 1 + list.length) % list.length)} aria-label="Projeto anterior" className="flex h-10 w-10 items-center justify-center rounded-full border border-ink/20 hover:border-ink"><ArrowLeft className="h-4 w-4" /></button>
              <button onClick={() => onIndex((index! + 1) % list.length)} aria-label="Próximo projeto" className="flex h-10 w-10 items-center justify-center rounded-full border border-ink/20 hover:border-ink"><ArrowRight className="h-4 w-4" /></button>
              <button ref={closeRef} onClick={onClose} aria-label="Fechar" className="ml-2 flex h-10 items-center gap-2 rounded-full bg-ink px-4 text-white">
                <span className="label">Fechar</span><X className="h-4 w-4" />
              </button>
            </div>
          </div>
          <div className="grid flex-1 overflow-y-auto md:grid-cols-12 md:overflow-hidden">
            <div className="relative flex items-center justify-center bg-bone p-6 md:col-span-8 md:p-12">
              <div className="absolute inset-0 bg-grid" />
              <motion.div
                key={p.slug}
                initial={{ opacity: 0, scale: 0.96 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.7, ease: [0.16, 1, 0.3, 1] }}
                className="relative w-full max-w-[min(100%,70vh)] shadow-[0_40px_80px_-40px_rgba(0,0,0,0.35)]"
              >
                {p.video ? (
                  <video src={p.video} controls playsInline className="w-full" />
                ) : (
                  <Artwork project={p} />
                )}
              </motion.div>
            </div>
            <motion.aside key={`${p.slug}-info`} initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} transition={{ duration: 0.6, delay: 0.1 }} className="flex flex-col gap-8 p-6 md:col-span-4 md:overflow-y-auto md:p-10">
              <div>
                <div className="flex items-center gap-3"><span className="label text-ash">{p.campaign} · {p.year}</span>{p.demo && <DemoBadge />}</div>
                <h2 className="display mt-4 text-5xl">{p.title}</h2>
                <p className="mt-5 text-lg leading-snug text-graphite">{p.summary}</p>
              </div>
              <dl className="grid grid-cols-2 gap-px border-y border-ink bg-line">
                {[["Tipo", p.type], ["Ano", String(p.year)], ["Campanha", p.campaign], ["Atleta", athlete?.name ?? "—"]].map(([k, v]) => (
                  <div key={k} className="bg-paper py-3 pr-3"><dt className="label text-ash">{k}</dt><dd className="mt-1 text-sm font-medium">{v}</dd></div>
                ))}
              </dl>
              <div>
                <p className="label mb-3">Behind the creation</p>
                <p className="leading-relaxed text-graphite">{p.behindTheScenes}</p>
              </div>
              {p.type === "Motion" && !p.video && (
                <p className="label border border-dashed border-ink/30 p-3 text-graphite">Vídeo a adicionar — defina `video` neste projeto.</p>
              )}
              {athlete && (
                <Link href={`/atletas/${athlete.slug}/`} onClick={onClose} className="mt-auto inline-flex items-center gap-3 self-start border-b border-ink pb-1 text-sm font-semibold uppercase tracking-[0.12em]">
                  Perfil de {athlete.shortName} <ArrowUpRight className="h-4 w-4" />
                </Link>
              )}
            </motion.aside>
          </div>
        </motion.div>
      )}
    </AnimatePresence>,
    document.body,
  );
}
