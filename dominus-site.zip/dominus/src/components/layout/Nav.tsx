"use client";
import { AnimatePresence, motion } from "framer-motion";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { useEffect, useState } from "react";
import { Logo } from "@/components/brand/Logo";
import { nav } from "@/lib/site";
import { cn } from "@/lib/utils";
import { scrollToId } from "./Providers";

function useClock() {
  const [t, setT] = useState("");
  useEffect(() => {
    const f = () => setT(new Date().toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit", second: "2-digit" }));
    f(); const i = setInterval(f, 1000); return () => clearInterval(i);
  }, []);
  return t;
}

export function Nav() {
  const pathname = usePathname();
  const onHome = pathname === "/";
  const [active, setActive] = useState("home");
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);
  const clock = useClock();

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  // Active section indicator
  useEffect(() => {
    if (!onHome) return;
    const els = nav.map((n) => document.getElementById(n.id)).filter(Boolean) as HTMLElement[];
    const io = new IntersectionObserver(
      (entries) => entries.forEach((e) => e.isIntersecting && setActive(e.target.id)),
      { rootMargin: "-45% 0px -50% 0px" },
    );
    els.forEach((el) => io.observe(el));
    return () => io.disconnect();
  }, [onHome]);

  useEffect(() => { setOpen(false); }, [pathname]);
  useEffect(() => {
    if (open) window.__lenis?.stop(); else window.__lenis?.start();
  }, [open]);

  const go = (id: string) => (e: React.MouseEvent) => {
    if (onHome && scrollToId(id)) { e.preventDefault(); history.replaceState(null, "", id === "home" ? "/" : `#${id}`); }
    setOpen(false);
  };

  return (
    <>
      <header
        className={cn(
          "fixed inset-x-0 top-0 z-50 transition-[background,border-color,padding] duration-500",
          scrolled || !onHome ? "glass border-b border-ink/10 py-3" : "border-b border-transparent py-5",
        )}
      >
        <nav aria-label="Principal" className="mx-auto flex max-w-[1600px] items-center gap-6 px-5 md:px-10">
          <Link href="/" onClick={go("home")} aria-label="DOMINUS® — início" className="shrink-0" data-cursor="hover">
            <Logo variant="word" className="h-[18px] w-auto md:h-5" />
          </Link>

          <ul className="mx-auto hidden items-center gap-1 lg:flex">
            {nav.slice(1).map((n) => {
              const isActive = onHome && active === n.id;
              return (
                <li key={n.id}>
                  <Link
                    href={`/#${n.id}`}
                    onClick={go(n.id)}
                    aria-current={isActive ? "true" : undefined}
                    className={cn("relative flex items-center gap-1.5 rounded-full px-3.5 py-2 transition-colors", isActive ? "text-ink" : "text-graphite hover:text-ink")}
                  >
                    {isActive && (
                      <motion.span layoutId="nav-active" className="absolute inset-0 rounded-full border border-ink/80" transition={{ type: "spring", stiffness: 380, damping: 32 }} />
                    )}
                    <span className="label-sm relative text-ash">{n.n}</span>
                    <span className="label relative">{n.label}</span>
                  </Link>
                </li>
              );
            })}
          </ul>

          <div className="ml-auto hidden items-center gap-5 lg:ml-0 lg:flex">
            <span className="label tabular-nums text-ash" suppressHydrationWarning>{clock || "--:--:--"}</span>
            <span className="flex items-center gap-2"><span className="h-1.5 w-1.5 rounded-full bg-ink blink" /><span className="label">Online</span></span>
          </div>

          <button
            className="ml-auto flex items-center gap-3 lg:hidden"
            onClick={() => setOpen((v) => !v)}
            aria-expanded={open}
            aria-controls="mobile-menu"
          >
            <span className="label">{open ? "Fechar" : "Menu"}</span>
            <span className="relative block h-3 w-6">
              <span className={cn("absolute left-0 h-px w-6 bg-ink transition-all duration-500", open ? "top-1.5 rotate-45" : "top-0")} />
              <span className={cn("absolute left-0 h-px w-6 bg-ink transition-all duration-500", open ? "top-1.5 -rotate-45" : "top-3")} />
            </span>
          </button>
        </nav>
      </header>

      <AnimatePresence>
        {open && (
          <motion.div
            id="mobile-menu"
            className="fixed inset-0 z-40 flex flex-col bg-paper px-5 pb-8 pt-24 lg:hidden"
            initial={{ clipPath: "inset(0 0 100% 0)" }}
            animate={{ clipPath: "inset(0 0 0% 0)" }}
            exit={{ clipPath: "inset(0 0 100% 0)" }}
            transition={{ duration: 0.8, ease: [0.76, 0, 0.24, 1] }}
          >
            <div className="absolute inset-0 bg-grid opacity-50" />
            <ul className="relative flex flex-1 flex-col justify-center gap-1">
              {nav.map((n, i) => (
                <motion.li key={n.id} initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.25 + i * 0.05, duration: 0.7, ease: [0.16, 1, 0.3, 1] }}>
                  <Link href={`/#${n.id}`} onClick={go(n.id)} className="flex items-baseline gap-4 border-b hairline py-3">
                    <span className="label text-ash">{n.n}</span>
                    <span className="display text-[2.6rem]">{n.label}</span>
                  </Link>
                </motion.li>
              ))}
            </ul>
            <div className="relative flex justify-between">
              <span className="label text-ash">DOMINUS® — Marketing Desportivo</span>
              <span className="label tabular-nums" suppressHydrationWarning>{clock}</span>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
