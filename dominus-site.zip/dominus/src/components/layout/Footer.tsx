import Link from "next/link";
import { Logo } from "@/components/brand/Logo";
import { IS_DEMO } from "@/data";
import { nav, site } from "@/lib/site";

export function Footer() {
  return (
    <footer className="relative overflow-hidden border-t hairline bg-paper">
      <div className="mx-auto max-w-[1600px] px-5 pt-16 md:px-10">
        <div className="grid gap-12 md:grid-cols-12">
          <div className="md:col-span-5">
            <p className="label text-ash">DOMINUS® — Marketing Desportivo</p>
            <p className="mt-4 max-w-sm text-lg leading-snug text-graphite">
              Identidade, visibilidade e oportunidades para atletas além do campo.
            </p>
          </div>
          <div className="md:col-span-3">
            <p className="label mb-4 text-ash">Navegação</p>
            <ul className="space-y-2">
              {nav.map((n) => (
                <li key={n.id}><Link href={`/#${n.id}`} className="text-sm uppercase tracking-[0.12em] hover:underline">{n.label}</Link></li>
              ))}
            </ul>
          </div>
          <div className="md:col-span-4">
            <p className="label mb-4 text-ash">Contato</p>
            <p className="text-sm">{site.email || <span className="text-ash">E-mail oficial — a definir</span>}</p>
            <ul className="mt-4 flex flex-wrap gap-x-5 gap-y-2">
              {site.socials.map((s) =>
                s.href ? (
                  <li key={s.label}><a href={s.href} target="_blank" rel="noreferrer" className="text-sm uppercase tracking-[0.12em] hover:underline">{s.label}</a></li>
                ) : (
                  <li key={s.label} className="text-sm uppercase tracking-[0.12em] text-ash" title="Link a definir">{s.label}</li>
                ),
              )}
            </ul>
          </div>
        </div>

        <div className="mt-20 select-none text-ink" aria-hidden>
          <Logo variant="word" className="w-full" />
        </div>

        <div className="mt-8 flex flex-col gap-3 border-t hairline py-6 md:flex-row md:items-center md:justify-between">
          <span className="label text-ash">© {new Date().getFullYear()} DOMINUS®. Todos os direitos reservados.</span>
          {IS_DEMO && (
            <span className="label text-ash">Atletas, clubes, projetos e números exibidos são dados de demonstração.</span>
          )}
        </div>
      </div>
    </footer>
  );
}
