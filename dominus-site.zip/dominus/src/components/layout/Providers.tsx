"use client";
import { MotionConfig } from "framer-motion";
import Lenis from "lenis";
import { createContext, useContext, useEffect, useState } from "react";

type Ctx = { ready: boolean; setReady: (v: boolean) => void };
const ReadyCtx = createContext<Ctx>({ ready: true, setReady: () => {} });
/** `ready` flips to true once the intro loader has finished. */
export const useReady = () => useContext(ReadyCtx).ready;
export const useSetReady = () => useContext(ReadyCtx).setReady;

declare global {
  interface Window { __lenis?: Lenis }
}

/** Smooth-scrolls to an element id, through Lenis when it is active. */
export function scrollToId(id: string) {
  const el = document.getElementById(id);
  if (!el) return false;
  if (window.__lenis) window.__lenis.scrollTo(el, { offset: id === "home" ? 0 : -64, duration: 1.4 });
  else el.scrollIntoView({ behavior: "smooth" });
  return true;
}

export function Providers({ children }: { children: React.ReactNode }) {
  const [ready, setReady] = useState(false);

  useEffect(() => {
    const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    if (reduce) return;
    const lenis = new Lenis({ duration: 1.15, easing: (t) => 1 - Math.pow(1 - t, 4), smoothWheel: true });
    window.__lenis = lenis;
    let raf = 0;
    const loop = (t: number) => { lenis.raf(t); raf = requestAnimationFrame(loop); };
    raf = requestAnimationFrame(loop);
    return () => { cancelAnimationFrame(raf); lenis.destroy(); window.__lenis = undefined; };
  }, []);

  // Honour #hash on first load (e.g. arriving from an athlete page via /#contact)
  useEffect(() => {
    if (!ready) return;
    const id = decodeURIComponent(window.location.hash.slice(1));
    if (id) setTimeout(() => scrollToId(id), 200);
  }, [ready]);

  return (
    <ReadyCtx.Provider value={{ ready, setReady }}>
      <MotionConfig reducedMotion="user">{children}</MotionConfig>
    </ReadyCtx.Provider>
  );
}
