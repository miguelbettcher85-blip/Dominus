"use client";
import { motion, useMotionValue, useSpring } from "framer-motion";
import { useEffect, useState } from "react";

/**
 * Two-part cursor: a precise dot and a lagging ring.
 * Elements opt in with data-cursor="hover" or data-cursor-label="Ver".
 * Only active on fine pointers and when reduced motion is off.
 */
export function Cursor() {
  const [enabled, setEnabled] = useState(false);
  const [mode, setMode] = useState<"idle" | "hover" | "label">("idle");
  const [label, setLabel] = useState("");
  const [down, setDown] = useState(false);
  const x = useMotionValue(-100);
  const y = useMotionValue(-100);
  const rx = useSpring(x, { stiffness: 380, damping: 32, mass: 0.6 });
  const ry = useSpring(y, { stiffness: 380, damping: 32, mass: 0.6 });

  useEffect(() => {
    const fine = window.matchMedia("(pointer: fine)").matches;
    const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    if (!fine || reduce) return;
    setEnabled(true);
    document.documentElement.classList.add("has-cursor");
    const move = (e: PointerEvent) => {
      x.set(e.clientX); y.set(e.clientY);
      const t = (e.target as HTMLElement)?.closest?.("[data-cursor-label],[data-cursor],a,button,input,textarea,select,label") as HTMLElement | null;
      if (!t) { setMode("idle"); return; }
      const l = t.getAttribute("data-cursor-label");
      if (l) { setMode("label"); setLabel(l); } else setMode("hover");
    };
    const d = () => setDown(true);
    const u = () => setDown(false);
    window.addEventListener("pointermove", move);
    window.addEventListener("pointerdown", d);
    window.addEventListener("pointerup", u);
    return () => {
      window.removeEventListener("pointermove", move);
      window.removeEventListener("pointerdown", d);
      window.removeEventListener("pointerup", u);
      document.documentElement.classList.remove("has-cursor");
    };
  }, [x, y]);

  if (!enabled) return null;
  const size = mode === "label" ? 84 : mode === "hover" ? 44 : 26;
  return (
    <>
      <motion.div
        aria-hidden
        className={`pointer-events-none fixed left-0 top-0 z-[200] flex items-center justify-center rounded-full border ${mode === "label" ? "border-ink" : "border-white mix-blend-difference"}`}
        style={{ x: rx, y: ry, translateX: "-50%", translateY: "-50%" }}
        animate={{
          width: size, height: size,
          backgroundColor: mode === "label" ? "rgba(10,10,10,1)" : "rgba(10,10,10,0)",
          scale: down ? 0.85 : 1,
        }}
        transition={{ type: "spring", stiffness: 300, damping: 26 }}
      >
        {mode === "label" && <span className="label-sm text-white">{label}</span>}
      </motion.div>
      <motion.div
        aria-hidden
        className="pointer-events-none fixed left-0 top-0 z-[201] h-1.5 w-1.5 rounded-full bg-white mix-blend-difference"
        style={{ x, y, translateX: "-50%", translateY: "-50%", opacity: mode === "label" ? 0 : 1 }}
      />
    </>
  );
}
