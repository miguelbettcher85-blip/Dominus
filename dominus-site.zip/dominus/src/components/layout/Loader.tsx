"use client";
import { AnimatePresence, motion } from "framer-motion";
import { useEffect, useState } from "react";
import { Logo } from "@/components/brand/Logo";
import { useSetReady } from "./Providers";

const STEPS = ["Inicializando grid", "Carregando atletas", "Calibrando scan", "Sincronizando arquivo", "Sistema pronto"];

/** Intro sequence, shown once per browser session. */
export function Loader() {
  const setReady = useSetReady();
  const [show, setShow] = useState(true);
  const [p, setP] = useState(0);

  useEffect(() => {
    let seen = false;
    try { seen = sessionStorage.getItem("dominus:intro") === "1"; } catch {}
    const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    if (seen || reduce) { setShow(false); setReady(true); return; }
    document.documentElement.style.overflow = "hidden";
    const start = performance.now();
    const total = 2300;
    let raf = 0;
    const tick = (t: number) => {
      const k = Math.min(1, (t - start) / total);
      const eased = 1 - Math.pow(1 - k, 3);
      setP(Math.round(eased * 100));
      if (k < 1) raf = requestAnimationFrame(tick);
      else setTimeout(() => {
        setShow(false);
        document.documentElement.style.overflow = "";
        try { sessionStorage.setItem("dominus:intro", "1"); } catch {}
        setTimeout(() => setReady(true), 250);
      }, 350);
    };
    raf = requestAnimationFrame(tick);
    return () => { cancelAnimationFrame(raf); document.documentElement.style.overflow = ""; };
  }, [setReady]);

  const step = STEPS[Math.min(STEPS.length - 1, Math.floor((p / 100) * STEPS.length))];

  return (
    <AnimatePresence>
      {show && (
        <motion.div
          key="loader"
          className="fixed inset-0 z-[100] flex flex-col bg-paper text-ink"
          exit={{ clipPath: "inset(0 0 100% 0)" }}
          initial={{ clipPath: "inset(0 0 0% 0)" }}
          transition={{ duration: 1, ease: [0.76, 0, 0.24, 1] }}
          aria-hidden
        >
          <div className="absolute inset-0 bg-grid opacity-60" />
          <div className="relative flex items-center justify-between px-6 pt-6 md:px-10">
            <span className="label">DOMINUS® / SYS</span>
            <span className="label text-ash">N 38°43′ · W 09°08′</span>
          </div>
          <div className="relative flex flex-1 flex-col items-center justify-center gap-10">
            <div className="relative w-[min(70vw,520px)]">
              <motion.div
                initial={{ clipPath: "inset(0 100% 0 0)" }}
                animate={{ clipPath: "inset(0 0% 0 0)" }}
                transition={{ duration: 1.6, ease: [0.76, 0, 0.24, 1] }}
              >
                <Logo className="w-full" />
              </motion.div>
              <div className="scanline" />
            </div>
          </div>
          <div className="relative px-6 pb-8 md:px-10">
            <div className="mb-4 flex items-end justify-between">
              <span className="label">
                {step}
                <span className="blink">_</span>
              </span>
              <span className="font-mono text-5xl font-light tabular-nums md:text-7xl">{String(p).padStart(3, "0")}</span>
            </div>
            <div className="h-px w-full bg-line">
              <div className="h-px bg-ink transition-[width] duration-100" style={{ width: `${p}%` }} />
            </div>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
