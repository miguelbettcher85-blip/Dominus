"use client";
import { motion } from "framer-motion";
import { ArrowUpRight } from "lucide-react";
import Link from "next/link";
import type { Athlete } from "@/data/types";
import { AthleteVisual } from "@/components/visuals/AthleteVisual";
import { DemoBadge } from "@/components/ui/Primitives";

export function AthleteCard({ athlete, index }: { athlete: Athlete; index: number }) {
  const top = athlete.stats.season.slice(0, 3);
  return (
    <motion.article
      layout
      initial={{ opacity: 0, y: 30 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, scale: 0.96 }}
      transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
      className="group"
    >
      <Link href={`/atletas/${athlete.slug}/`} data-cursor-label="Perfil" className="block">
        <div className="relative aspect-[3/4] overflow-hidden bg-bone">
          <div className="h-full w-full transition-transform duration-[1.2s] ease-out-expo group-hover:scale-[1.06]">
            <AthleteVisual athlete={athlete} showLabel={false} />
          </div>
          {/* hover: scanning sweep + data overlay */}
          <div className="pointer-events-none absolute inset-0 opacity-0 transition-opacity duration-500 group-hover:opacity-100 group-focus-visible:opacity-100">
            <div className="scanline" />
          </div>
          <div className="absolute left-3 top-3 flex items-center gap-2">
            <span className="label-sm bg-paper px-1.5 py-0.5">{String(index + 1).padStart(2, "0")}</span>
            {athlete.emerging && <span className="label-sm bg-ink px-1.5 py-0.5 text-white">Talent</span>}
          </div>
          <span className="label-sm absolute right-3 top-3 text-graphite">#{athlete.number}</span>
          <div className="absolute inset-x-0 bottom-0 translate-y-full bg-ink p-4 text-white transition-transform duration-700 ease-out-expo group-hover:translate-y-0 group-focus-visible:translate-y-0">
            <div className="grid grid-cols-3 gap-2">
              {top.map((s) => (
                <div key={s.label}>
                  <div className="text-xl font-semibold tabular-nums">{s.value}{s.suffix}</div>
                  <div className="label-sm text-white/50">{s.label}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
        <div className="mt-4 flex items-start justify-between gap-3">
          <div>
            <h3 className="text-lg font-semibold uppercase leading-tight tracking-[-0.01em]">{athlete.name}</h3>
            <p className="label mt-1 text-graphite">{athlete.position} · {athlete.club}</p>
          </div>
          <span className="mt-1 flex h-8 w-8 shrink-0 items-center justify-center rounded-full border border-ink/20 transition-colors duration-500 group-hover:border-ink group-hover:bg-ink group-hover:text-white">
            <ArrowUpRight className="h-4 w-4" />
          </span>
        </div>
        <div className="mt-3 flex items-center gap-3 border-t hairline pt-3">
          <span className="label text-ash">{athlete.countryCode}</span>
          <span className="label text-ash">{athlete.nationality}</span>
          <span className="label text-ash">· {athlete.category}</span>
          {athlete.demo && <DemoBadge className="ml-auto" />}
        </div>
      </Link>
    </motion.article>
  );
}
