"use client";
import { AnimatePresence, motion } from "framer-motion";
import { ArrowLeft, ArrowUpRight, X } from "lucide-react";
import Link from "next/link";
import { useEffect, useState } from "react";
import { ProjectModal } from "@/components/projects/ProjectModal";
import { ProjectTile } from "@/components/projects/ProjectTile";
import { PerformanceRoom } from "@/components/sections/PerformanceRoom";
import { Counter } from "@/components/ui/Counter";
import { Brackets, DemoBadge, SectionHead } from "@/components/ui/Primitives";
import { Reveal } from "@/components/ui/Reveal";
import { SplitText } from "@/components/ui/SplitText";
import { AthleteVisual } from "@/components/visuals/AthleteVisual";
import type { Athlete, Project } from "@/data/types";
import { age } from "@/lib/utils";

export function AthleteProfile({ athlete: a, next, squad, projects }: { athlete: Athlete; next: Athlete; squad: Athlete[]; projects: Project[] }) {
  const [idx, setIdx] = useState<number | null>(null);
  const [shot, setShot] = useState<number | null>(null);
  const [first, ...rest] = a.name.split(" ");

  useEffect(() => {
    if (shot === null) return;
    const k = (e: KeyboardEvent) => e.key === "Escape" && setShot(null);
    window.addEventListener("keydown", k); window.__lenis?.stop();
    return () => { window.removeEventListener("keydown", k); window.__lenis?.start(); };
  }, [shot]);

  const meta = [
    ["Nacionalidade", a.nationality],
    ["Clube atual", a.club],
    ["Posição", a.position],
    ["Categoria", a.category],
    ["Idade", `${age(a.born)} anos`],
    ["Altura", `${(a.heightCm / 100).toFixed(2).replace(".", ",")} m`],
    ["Pé", a.foot],
    ["Camisa", `#${a.number}`],
  ];

  return (
    <article className="pt-24 md:pt-28">
      {/* ── Hero ── */}
      <header className="relative mx-auto max-w-[1600px] px-5 md:px-10">
        <div className="flex items-center justify-between border-b hairline pb-4">
          <Link href="/#athletes" className="label inline-flex items-center gap-2 hover:underline" data-cursor="hover"><ArrowLeft className="h-3.5 w-3.5" /> Athlete Universe</Link>
          <div className="flex items-center gap-3">{a.demo && <DemoBadge />}<span className="label text-ash">Perfil · {a.countryCode}-{String(a.number).padStart(2, "0")}</span></div>
        </div>

        <div className="mt-8 grid gap-8 md:mt-12 md:grid-cols-12">
          <div className="md:col-span-7">
            <p className="label">{a.position} · {a.club}</p>
            <SplitText as="h1" className="display mt-4 text-[clamp(2.4rem,7.4vw,8rem)]" lines={[first, <span key="l" className="text-outline">{rest.join(" ")}</span>]} />
            <p className="mt-8 max-w-xl text-lg leading-relaxed text-graphite md:text-xl">{a.bio}</p>
            <dl className="mt-10 grid grid-cols-2 gap-px border-y border-ink bg-line sm:grid-cols-4">
              {meta.map(([k, v]) => (
                <div key={k} className="bg-paper py-4 pr-3"><dt className="label text-ash">{k}</dt><dd className="mt-1 font-semibold uppercase">{v}</dd></div>
              ))}
            </dl>
          </div>
          <motion.div className="relative md:col-span-5" initial={{ clipPath: "inset(100% 0 0 0)" }} animate={{ clipPath: "inset(0% 0 0 0)" }} transition={{ duration: 1.2, delay: 0.3, ease: [0.76, 0, 0.24, 1] }}>
            <div className="relative aspect-[4/5] overflow-hidden bg-ink">
              <AthleteVisual athlete={a} tone="dark" />
              <div className="scanline scanline-light" />
              <Brackets dark className="m-4" />
            </div>
          </motion.div>
        </div>

        <div className="mt-16 grid grid-cols-2 gap-px border-y border-ink bg-line md:grid-cols-4">
          {a.stats.season.map((s) => (
            <div key={s.label} className="bg-paper py-8 pr-4">
              <Counter value={s.value} suffix={s.suffix} className="block text-5xl font-semibold tabular-nums tracking-[-0.04em] md:text-7xl" />
              <span className="label mt-3 block text-graphite">{s.label} · temporada</span>
            </div>
          ))}
        </div>
      </header>

      {/* ── Performance Room ── */}
      <section className="mt-24 bg-ink py-16 text-white md:py-24">
        <div className="mx-auto max-w-[1600px] px-5 md:px-10">
          <SectionHead dark index="A" name="Performance Room" coord="Atributos 0–100" />
          <PerformanceRoom athletes={squad} embedded />
        </div>
      </section>

      {/* ── Career ── */}
      <section className="mx-auto max-w-[1600px] px-5 py-24 md:px-10 md:py-32">
        <SectionHead index="B" name="Career History" coord={`${a.career.length} clubes`} />
        <ol className="mt-10">
          {a.career.map((c, i) => (
            <Reveal key={c.season + c.club} delay={i * 0.06}>
              <li className="group grid grid-cols-[90px_1fr] items-baseline gap-4 border-b hairline py-6 md:grid-cols-[160px_1fr_1fr_120px_120px]">
                <span className="label tabular-nums">{c.season}</span>
                <span className="text-2xl font-semibold uppercase tracking-[-0.02em] md:text-4xl">{c.club}</span>
                <span className="label col-start-2 text-graphite md:col-start-auto">{c.competition}</span>
                <span className="label col-start-2 tabular-nums md:col-start-auto">{c.apps ?? "—"} jogos</span>
                <span className="label col-start-2 tabular-nums md:col-start-auto">{c.goals ?? "—"} gols</span>
              </li>
            </Reveal>
          ))}
        </ol>
      </section>

      {/* ── Gallery ── */}
      <section className="bg-bone py-24 md:py-32">
        <div className="mx-auto max-w-[1600px] px-5 md:px-10">
          <SectionHead index="C" name="Gallery" coord={`${a.gallery.length} imagens`} />
          <div className="mt-10 grid grid-cols-2 gap-4 md:grid-cols-12 md:gap-6">
            {a.gallery.map((g, i) => (
              <button key={i} onClick={() => setShot(i)} data-cursor-label="Ver"
                className={`group relative overflow-hidden text-left ${i % 3 === 0 ? "col-span-2 aspect-[16/10] md:col-span-7" : "aspect-[4/5] md:col-span-5"}`}>
                {g.src ? (
                  // eslint-disable-next-line @next/next/no-img-element
                  <img src={g.src} alt={g.caption} loading="lazy" className="h-full w-full object-cover grayscale transition-transform duration-700 group-hover:scale-105" />
                ) : (
                  <div className="h-full w-full transition-transform duration-700 group-hover:scale-105"><AthleteVisual athlete={{ ...a, number: a.number + i * 7 }} tone={i % 2 ? "dark" : "light"} showLabel={false} /></div>
                )}
                <span className="label absolute bottom-3 left-3 bg-paper px-2 py-1">{String(i + 1).padStart(2, "0")} — {g.caption}</span>
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* ── Projects ── */}
      {projects.length > 0 && (
        <section className="mx-auto max-w-[1600px] px-5 py-24 md:px-10 md:py-32">
          <SectionHead index="D" name="Projects" coord={`${projects.length} no arquivo`} />
          <div className="mt-10 columns-1 gap-6 sm:columns-2 lg:columns-3">
            {projects.map((p, i) => <ProjectTile key={p.slug} project={p} index={i} onOpen={() => setIdx(i)} />)}
          </div>
          <ProjectModal list={projects} index={idx} onClose={() => setIdx(null)} onIndex={setIdx} athletes={squad} />
        </section>
      )}

      {/* ── Next ── */}
      <Link href={`/atletas/${next.slug}/`} data-cursor-label="Próximo" className="group block border-t border-ink bg-paper">
        <div className="mx-auto flex max-w-[1600px] items-end justify-between gap-6 px-5 py-16 md:px-10 md:py-24">
          <div>
            <span className="label text-ash">Próximo atleta</span>
            <span className="display mt-4 block text-[clamp(2rem,6.4vw,6.5rem)] transition-transform duration-700 ease-out-expo group-hover:translate-x-4">{next.name}</span>
          </div>
          <ArrowUpRight className="h-12 w-12 shrink-0 transition-transform duration-500 group-hover:rotate-45 md:h-20 md:w-20" strokeWidth={1} />
        </div>
      </Link>

      {/* Lightbox */}
      <AnimatePresence>
        {shot !== null && (
          <motion.div role="dialog" aria-modal="true" aria-label={a.gallery[shot].caption} className="fixed inset-0 z-[80] flex items-center justify-center bg-paper/95 p-6 backdrop-blur"
            initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onClick={() => setShot(null)}>
            <button autoFocus onClick={() => setShot(null)} aria-label="Fechar" className="absolute right-5 top-5 flex h-11 w-11 items-center justify-center rounded-full bg-ink text-white"><X className="h-5 w-5" /></button>
            <motion.figure initial={{ scale: 0.95 }} animate={{ scale: 1 }} className="w-full max-w-3xl" onClick={(e) => e.stopPropagation()}>
              <div className="aspect-[4/5] max-h-[78vh] w-full overflow-hidden md:aspect-[16/10]">
                {a.gallery[shot].src
                  // eslint-disable-next-line @next/next/no-img-element
                  ? <img src={a.gallery[shot].src} alt={a.gallery[shot].caption} className="h-full w-full object-contain" />
                  : <AthleteVisual athlete={{ ...a, number: a.number + shot * 7 }} tone={shot % 2 ? "dark" : "light"} />}
              </div>
              <figcaption className="label mt-3">{String(shot + 1).padStart(2, "0")} / {String(a.gallery.length).padStart(2, "0")} — {a.gallery[shot].caption}</figcaption>
            </motion.figure>
          </motion.div>
        )}
      </AnimatePresence>
    </article>
  );
}
