import "server-only";
import { geoContains, geoNaturalEarth1 } from "d3-geo";
import { feature } from "topojson-client";
import countriesTopo from "world-atlas/countries-110m.json";
import type { Market } from "@/data/types";

// Computed at build time (server component) — ships only the dot coordinates.

const ATLAS_NAME: Record<string, string> = {
  pt: "Portugal", br: "Brazil", es: "Spain", it: "Italy", uk: "United Kingdom",
  ae: "United Arab Emirates", us: "United States of America", jp: "Japan",
};

export const MAP_W = 1000;
export const MAP_H = 500;

export type Dot = [number, number, string?]; // x, y, marketId
export type MapData = { dots: Dot[]; markets: (Market & { x: number; y: number })[] };

export function buildWorldMap(markets: Market[], step = 9): MapData {
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const topo = countriesTopo as any;
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const countries = (feature(topo, topo.objects.countries) as any).features as any[];
  const land = countries.filter((c) => c.properties?.name !== "Antarctica");
  const projection = geoNaturalEarth1().fitExtent([[10, 10], [MAP_W - 10, MAP_H - 10]], { type: "FeatureCollection", features: land });

  const byMarket = markets
    .map((m) => ({ id: m.id, f: countries.find((c) => c.properties?.name === ATLAS_NAME[m.id]) }))
    .filter((x) => x.f);

  const dots: Dot[] = [];
  for (let y = step / 2; y < MAP_H; y += step) {
    for (let x = step / 2; x < MAP_W; x += step) {
      const ll = projection.invert?.([x, y]);
      if (!ll || !isFinite(ll[0])) continue;
      const hit = land.find((c) => geoContains(c, ll));
      if (!hit) continue;
      const m = byMarket.find((b) => b.f === hit);
      dots.push(m ? [Math.round(x * 10) / 10, Math.round(y * 10) / 10, m.id] : [Math.round(x * 10) / 10, Math.round(y * 10) / 10]);
    }
  }
  const placed = markets.map((m) => {
    const [x, y] = projection(m.coords) ?? [0, 0];
    return { ...m, x: Math.round(x * 10) / 10, y: Math.round(y * 10) / 10 };
  });
  return { dots, markets: placed };
}
