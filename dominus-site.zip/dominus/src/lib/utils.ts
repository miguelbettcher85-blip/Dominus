export const cn = (...c: (string | false | null | undefined)[]) => c.filter(Boolean).join(" ");
export const pad = (n: number, l = 2) => String(n).padStart(l, "0");
export const age = (iso: string, now = new Date()) => {
  const b = new Date(iso);
  let a = now.getFullYear() - b.getFullYear();
  if (now < new Date(now.getFullYear(), b.getMonth(), b.getDate())) a--;
  return a;
};
export const initials = (name: string) =>
  name.split(" ").filter(Boolean).map((p) => p[0]).slice(0, 2).join("").toUpperCase();
