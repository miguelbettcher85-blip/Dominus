// Global site settings. Values left empty are shown as "a definir" on the site
// instead of inventing contact details.
export const site = {
  name: "DOMINUS®",
  tagline: "Marketing Desportivo",
  url: "https://dominus.example", // ← replace with the real domain
  description:
    "DOMINUS® — agência de marketing desportivo e branding de atletas. Construímos identidade, visibilidade e oportunidades para atletas além do campo.",
  email: "", // ← official e-mail, e.g. "contato@seudominio.com"
  socials: [
    { label: "Instagram", href: "" },
    { label: "LinkedIn", href: "" },
    { label: "YouTube", href: "" },
    { label: "TikTok", href: "" },
  ],
  formEndpoint: process.env.NEXT_PUBLIC_FORM_ENDPOINT ?? "",
};

// `n` matches the section index shown on the page. "Services" opens Player
// Development (04); Our Expertise (06) follows Global, as in the brief.
export const nav = [
  { id: "home", label: "Home", n: "01" },
  { id: "athletes", label: "Athletes", n: "02" },
  { id: "creative-lab", label: "Creative Lab", n: "03" },
  { id: "services", label: "Services", n: "04" },
  { id: "global", label: "Global", n: "05" },
  { id: "archive", label: "Archive", n: "07" },
  { id: "contact", label: "Contact", n: "08" },
] as const;
