import * as prod from "./production";
import { demoAthletes, demoAthleteOfTheMonth } from "./demo/athletes";
import { demoProjects } from "./demo/projects";
import { demoMarkets, demoMilestones, demoReach } from "./demo/global";

/** True while the site shows demonstration content. */
export const IS_DEMO = process.env.NEXT_PUBLIC_USE_DEMO_DATA !== "false";

export const athletes = IS_DEMO ? demoAthletes : prod.athletes;
export const athleteOfTheMonth = IS_DEMO ? demoAthleteOfTheMonth : prod.athleteOfTheMonth;
export const projects = IS_DEMO ? demoProjects : prod.projects;
export const markets = IS_DEMO ? demoMarkets : prod.markets;
export const milestones = IS_DEMO ? demoMilestones : prod.milestones;
export const reach = IS_DEMO ? demoReach : prod.reach;

export const getAthlete = (slug: string) => athletes.find((a) => a.slug === slug);
export const projectsFor = (slug: string) => projects.filter((p) => p.athleteSlug === slug);

export * from "./types";
