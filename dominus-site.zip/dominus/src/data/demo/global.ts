import type { Market, Milestone } from "../types";

// DEMONSTRATION DATA — markets, milestones and reach numbers are illustrative.
// They do not describe real partnerships, offices or achievements.

export const demoMarkets: Market[] = [
  { id: "pt", country: "Portugal", coords: [-9.14, 38.72], role: "hub", since: 2024, note: "Base de operação (demo)", competitions: ["Liga Portugal", "Liga BPI"] },
  { id: "br", country: "Brasil", coords: [-46.63, -23.55], role: "active", since: 2024, note: "Captação e produção (demo)", competitions: ["Brasileirão", "Copa do Brasil"] },
  { id: "es", country: "Espanha", coords: [-3.7, 40.42], role: "active", since: 2025, note: "Atletas representados (demo)", competitions: ["LaLiga", "Segunda División"] },
  { id: "it", country: "Itália", coords: [12.5, 41.9], role: "prospect", since: 2026, note: "Mercado em análise (demo)", competitions: ["Serie A", "Serie B"] },
  { id: "uk", country: "Inglaterra", coords: [-0.12, 51.5], role: "prospect", since: 2026, note: "Mercado em análise (demo)", competitions: ["Premier League", "Championship"] },
  { id: "ae", country: "Emirados Árabes", coords: [55.27, 25.2], role: "prospect", since: 2027, note: "Mercado em análise (demo)", competitions: ["UAE Pro League"] },
  { id: "us", country: "Estados Unidos", coords: [-74.0, 40.71], role: "prospect", since: 2027, note: "Mercado em análise (demo)", competitions: ["MLS"] },
  { id: "jp", country: "Japão", coords: [139.69, 35.68], role: "prospect", since: 2027, note: "Mercado em análise (demo)", competitions: ["J1 League"] },
];

export const demoMilestones: Milestone[] = [
  { year: 2024, quarter: "Q1", title: "Fundação", description: "Início da DOMINUS® e definição da identidade visual.", marketId: "pt" },
  { year: 2024, quarter: "Q3", title: "Primeiros atletas", description: "Primeiro grupo de atletas acompanhados em branding e conteúdo.", marketId: "br" },
  { year: 2025, quarter: "Q2", title: "Creative Lab", description: "Abertura do estúdio criativo interno para matchday e motion.", marketId: "pt" },
  { year: 2025, quarter: "Q4", title: "Expansão ibérica", description: "Primeiros projetos com atletas em Espanha.", marketId: "es" },
  { year: 2026, quarter: "Q2", title: "Plataforma digital", description: "Lançamento do Athlete Universe e do arquivo online.", marketId: "pt" },
  { year: 2027, title: "Próximos mercados", description: "Planejamento de presença em novos mercados internacionais.", marketId: "uk" },
];

export const demoReach = [
  { label: "Países", value: 8 },
  { label: "Atletas no elenco", value: 8 },
  { label: "Peças produzidas", value: 1200, suffix: "+" },
  { label: "Alcance mensal", value: 4.6, suffix: "M", decimals: 1 },
];
