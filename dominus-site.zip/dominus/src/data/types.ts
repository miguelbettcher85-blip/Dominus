// Shared content model. Demo data (src/data/demo) and production data
// (src/data/production) both follow these types, so swapping one for the
// other never touches the components.

export type Position = "Goleiro" | "Zagueiro" | "Lateral" | "Volante" | "Meia" | "Ponta" | "Atacante";
export type Category = "Profissional" | "Sub-23" | "Sub-20" | "Sub-17" | "Feminino";

export interface CareerStep {
  season: string; // "2023–24"
  club: string;
  competition?: string;
  apps?: number;
  goals?: number;
}

export interface AthleteStats {
  /** 0–100 attribute ratings used by the radar in the Performance Room */
  attributes: { label: string; value: number }[];
  /** Season numbers shown as counters */
  season: { label: string; value: number; suffix?: string }[];
}

export interface Athlete {
  slug: string;
  name: string;
  shortName: string;
  number: number;
  nationality: string; // country name
  countryCode: string; // ISO-3166 alpha-2, used for labels
  club: string;
  position: Position;
  category: Category;
  foot: "Direito" | "Esquerdo" | "Ambidestro";
  heightCm: number;
  born: string; // ISO date
  bio: string;
  /** Path under /public. While empty, a typographic placeholder is rendered. */
  portrait?: string;
  gallery: { src?: string; caption: string }[];
  career: CareerStep[];
  stats: AthleteStats;
  /** Highlighted in "Talent Showcase" */
  emerging?: boolean;
  demo?: boolean;
}

export type ProjectType =
  | "Matchday"
  | "Motion"
  | "Anúncio de jogador"
  | "Carrossel"
  | "Campanha editorial"
  | "Experimental";

export interface Project {
  slug: string;
  title: string;
  type: ProjectType;
  athleteSlug?: string;
  campaign: string;
  year: number;
  summary: string;
  behindTheScenes: string;
  /** Visual proportion in the editorial grid */
  ratio: "square" | "portrait" | "landscape" | "tall";
  /** Path under /public; while empty a generated artwork placeholder is used. */
  cover?: string;
  /** For motion pieces: path to an mp4 under /public. Never faked. */
  video?: string;
  demo?: boolean;
}

export interface Market {
  id: string;
  country: string;
  coords: [number, number]; // [lon, lat]
  role: "hub" | "active" | "prospect";
  since: number;
  note: string;
  competitions: string[];
}

export interface Milestone {
  year: number;
  quarter?: string;
  title: string;
  description: string;
  marketId?: string;
}
