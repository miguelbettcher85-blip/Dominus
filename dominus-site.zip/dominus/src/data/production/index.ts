import type { Athlete, Market, Milestone, Project } from "../types";

// ─────────────────────────────────────────────────────────────────────────────
// PRODUCTION DATA — real DOMINUS® content goes here.
// 1. Fill these arrays (same shape as src/data/demo/*).
// 2. Put photos in /public/athletes and /public/projects and reference them
//    with `portrait`, `gallery[].src` and `cover`.
// 3. Set NEXT_PUBLIC_USE_DEMO_DATA=false.
// ─────────────────────────────────────────────────────────────────────────────

export const athletes: Athlete[] = [];
export const athleteOfTheMonth: { slug: string; month: string } | null = null;
export const projects: Project[] = [];
export const markets: Market[] = [];
export const milestones: Milestone[] = [];
export const reach: { label: string; value: number; suffix?: string; decimals?: number }[] = [];
